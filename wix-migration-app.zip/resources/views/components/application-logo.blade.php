<img src="{{ asset('logo/logo.webp') }}" class="h-16 m-px" alt="CT Migrator" />
