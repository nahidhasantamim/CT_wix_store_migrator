<?php
  // Map step titles to route names + file input keys
  $routeMap = [
    'Categories' => ['key' => 'categories', 'export' => 'wix.export.categories', 'import' => 'wix.import.categories', 'label' => 'Categories'],
    'Products' => ['key' => 'products', 'export' => 'wix.export.products', 'import' => 'wix.import.products', 'label' => 'Products'],
    'Orders' => ['key' => 'orders', 'export' => 'wix.export.orders', 'import' => 'wix.import.orders', 'label' => 'Orders'],
    'Discounts' => ['key' => 'discount_rules', 'export' => 'wix.export.discount.rules', 'import' => 'wix.import.discount.rules', 'label' => 'Discount Rules'],
    'Coupons' => ['key' => 'coupons', 'export' => 'wix.export.coupons', 'import' => 'wix.import.coupons', 'label' => 'Coupons'],
    'Gift Cards' => ['key' => 'gift_cards', 'export' => 'wix.export.gift.cards', 'import' => 'wix.import.gift.cards', 'label' => 'Gift Cards'],
    'Loyalty' => ['key' => 'loyalty', 'export' => 'wix.loyalty.export', 'import' => 'wix.loyalty.import', 'label' => 'Loyalty'],
    'Media' => ['key' => 'media', 'export' => 'wix.export.media', 'import' => 'wix.import.media', 'label' => 'Media'],
    'Contacts & Members' => ['key' => 'contacts', 'export' => 'wix.export.contacts', 'import' => 'wix.import.contacts', 'label' => 'Contacts & Members'], 
  ];
  // $isContactsMembers = ($title === 'Contacts & Members');
?>

<div class="bg-gray-800 text-white rounded-lg shadow p-5 sm:p-6">
  <h2 class="text-lg sm:text-xl font-semibold mb-1">Step <?php echo e($idx); ?> - <?php echo e($title); ?></h2>
  <p class="text-xs sm:text-sm text-gray-400 mb-4">Find all your connected stores below.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="relative rounded-lg border border-gray-700 bg-gray-900 p-4 sm:p-5 shadow min-h-[14rem] flex flex-col">
        
        <div class="absolute right-2 top-2">
          <button
            id="dropdownButton-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
            data-dropdown-toggle="dropdown-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
            data-dropdown-trigger="click"
            data-dropdown-placement="bottom-end"
            type="button"
            class="inline-flex items-center justify-center rounded-lg p-1.5 text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-600/40"
          >
            <span class="sr-only">Open menu</span>
            <svg class="w-5 h-5" viewBox="0 0 16 3" fill="currentColor" aria-hidden="true">
              <path d="M2 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm6.041 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM14 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z"/>
            </svg>
          </button>

          <div id="dropdown-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
               class="z-30 hidden w-44 rounded-lg border border-gray-200/10 bg-gray-50 text-base shadow-sm dark:bg-gray-800">
            <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownButton-<?php echo e($idx); ?>-<?php echo e($store->id); ?>">
              <li>
                <a href="#"
                   data-modal-target="rename-modal-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
                   data-modal-toggle="rename-modal-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
                   class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-white">
                  Rename Store
                </a>
              </li>
              <li>
                <button type="button"
                        class="block w-full text-left px-4 py-2 text-red-600 hover:bg-gray-100 dark:text-red-400 dark:hover:bg-gray-700"
                        x-data
                        x-on:click.prevent="$dispatch('open-modal','confirm-store-deletion-<?php echo e($idx); ?>-<?php echo e($store->id); ?>')">
                  Delete
                </button>
              </li>
            </ul>
          </div>
        </div>

        
        <div class="flex flex-col items-center mt-4 sm:mt-6">
          <?php if($store->store_logo): ?>
            <img class="w-24 h-24 mb-3 rounded-full shadow-lg border-4 border-dashed border-blue-800 object-cover"
                 src="<?php echo e(asset('storage/'.$store->store_logo)); ?>" alt="<?php echo e($store->store_name ?? 'Store Logo'); ?>">
          <?php else: ?>
            <img class="w-24 h-24 mb-3 rounded-full shadow-lg"
                 src="https://img.icons8.com/external-tal-revivo-color-tal-revivo/96/external-wixcom-ltd-is-an-israeli-cloud-based-web-development-logo-color-tal-revivo.png"
                 alt="<?php echo e($store->store_name ?? 'Wix Store Logo'); ?>">
          <?php endif; ?>

          <h5 class="mb-1 text-lg sm:text-xl font-semibold text-white text-center"><?php echo e($store->store_name); ?></h5>
          <span class="text-[11px] sm:text-xs text-gray-400 text-center">
            Instance ID: (<?php echo e(\Illuminate\Support\Str::limit($store->instance_id, 30, '…')); ?>)
          </span>
        </div>

        
        <div class="mt-4 grid w-full gap-3">

            <?php $conf = $routeMap[$title] ?? null; ?>
            <?php if($conf): ?>
              
              <div class="rounded-lg border border-gray-700 bg-gray-800 p-3 sm:p-4">
                <h3 class="text-sm font-semibold text-white mb-2 text-center">Export <?php echo e($conf['label']); ?></h3>

                <?php if(($conf['key'] ?? null) === 'orders'): ?>
                  
                  
                  <form action="<?php echo e(route($conf['export'], $store)); ?>" method="GET" class="space-y-3" x-data="{ useRange: false }">
                    
                    <label class="inline-flex items-center gap-2 text-sm text-gray-200">
                      <input type="checkbox" name="use_date_range" value="1"
                            x-model="useRange"
                            class="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500">
                      Filter by order creation date
                    </label>

                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2"
                        :class="{ 'opacity-100': useRange, 'opacity-60': !useRange }">
                      <div>
                        <label class="block text-xs text-gray-300 mb-1" for="date_from_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">Start date</label>
                        <input type="date" name="created_from" id="date_from_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                              class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                              :disabled="!useRange">
                      </div>
                      <div>
                        <label class="block text-xs text-gray-300 mb-1" for="date_to_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">End date</label>
                        <input type="date" name="created_to" id="date_to_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                              class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                              :disabled="!useRange">
                      </div>
                    </div>

                    
                    <div>
                      <label class="block text-xs text-gray-300 mb-1" for="limit_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">Max orders (optional)</label>
                      <input type="number" min="1" name="limit" id="limit_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                            class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                            placeholder="e.g. 200">
                    </div>

                    <p class="text-[11px] text-gray-400">
                      Dates are interpreted in <span class="font-medium text-gray-200">Pacific Time (PT)</span>, inclusive start/end of day.
                    </p>

                    <button type="submit"
                            class="inline-flex w-full items-center justify-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/60">
                      Download
                    </button>
                  </form>


                <?php elseif(($conf['key'] ?? null) === 'contacts'): ?>
                  
                  <form action="<?php echo e(route($conf['export'], $store)); ?>" method="GET" class="space-y-3" x-data="{ useRange: false }">
                    
                    <div>
                      <label class="block text-xs text-gray-300 mb-1" for="max_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">Max (optional)</label>
                      <input type="number" min="1" name="max" id="max_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                            class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                            placeholder="e.g. 500">
                    </div>

                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <label class="inline-flex items-center gap-2 text-sm text-gray-200">
                        <input type="checkbox" name="include_members" value="1" class="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500" checked>
                        Include Members
                      </label>
                      <label class="inline-flex items-center gap-2 text-sm text-gray-200">
                        <input type="checkbox" name="include_attachments" value="1" class="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500" checked>
                        Include Attachments
                      </label>
                    </div>

                    <div class="border-t border-gray-700 pt-3"></div>

                    
                    <label class="inline-flex items-center gap-2 text-sm text-gray-200">
                      <input type="checkbox" name="use_date_range" value="1"
                            x-model="useRange"
                            class="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500">
                      Filter by date range (Pacific Time)
                    </label>

                    
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-2"
                        :class="{ 'opacity-100': useRange, 'opacity-60': !useRange }">
                      <div>
                        <label class="block text-xs text-gray-300 mb-1" for="date_field_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">Date Field</label>
                        <select name="date_field" id="date_field_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                                class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                                :disabled="!useRange">
                          <option value="created" selected>Created</option>
                          <option value="updated">Updated</option>
                        </select>
                      </div>
                      <div>
                        <label class="block text-xs text-gray-300 mb-1" for="start_date_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">Start date</label>
                        <input type="date" name="start_date" id="start_date_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                              placeholder="YYYY-MM-DD or DD.MM.YYYY"
                              class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                              :disabled="!useRange">
                      </div>
                      <div>
                        <label class="block text-xs text-gray-300 mb-1" for="end_date_<?php echo e($idx); ?>_<?php echo e($store->id); ?>">End date</label>
                        <input type="date" name="end_date" id="end_date_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                              placeholder="YYYY-MM-DD or DD.MM.YYYY"
                              class="w-full rounded-md border border-gray-600 bg-gray-900 px-3 py-2 text-sm text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                              :disabled="!useRange">
                      </div>
                    </div>

                    <p class="text-[11px] text-gray-400">
                      Dates are interpreted in <span class="font-medium text-gray-200">America/Los_Angeles</span> (inclusive start/end of day).  
                      Accepts <code>YYYY-MM-DD</code> or <code>DD.MM.YYYY</code>.
                    </p>

                    <button type="submit"
                            class="inline-flex w-full items-center justify-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/60">
                      Download
                    </button>
                  </form>

                <?php else: ?>
                  
                  <a href="<?php echo e(route($conf['export'], $store)); ?>"
                    class="inline-flex w-full items-center justify-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/60">
                    Download
                  </a>
                <?php endif; ?>
              </div>

              <!-- NEW SYNC BUTTONS -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <!-- Source Store Sync -->
                <form action="<?php echo e(route('wix.contacts.syncSource', $store)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <button type="submit"
                          class="w-full inline-flex items-center justify-center text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-full text-sm py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                    Sync Source Contacts
                  </button>
                </form>

                <!-- Destination Store Sync -->
                <form action="<?php echo e(route('wix.contacts.syncDestination', $store)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <button type="submit"
                          class="w-full inline-flex items-center justify-center text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-full text-sm py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">
                    Sync Destination Contacts
                  </button>
                </form>
              </div>
              <!-- END NEW SYNC BUTTONS -->

              
              <div class="rounded-lg border border-gray-700 bg-gray-800 p-3 sm:p-4">
                <h3 class="text-sm font-semibold text-white mb-2 text-center">Import <?php echo e($conf['label']); ?></h3>
                <form action="<?php echo e(route($conf['import'], $store)); ?>" method="POST" enctype="multipart/form-data" class="w-full">
                  <?php echo csrf_field(); ?>
                  <div class="relative">
                    <input type="file"
                           name="<?php echo e($conf['key']); ?>_json"
                           id="<?php echo e($conf['key']); ?>_json_<?php echo e($idx); ?>_<?php echo e($store->id); ?>"
                           accept=".json"
                           class="block w-full cursor-pointer rounded-lg border border-gray-600 bg-gray-900 text-sm text-gray-200 file:mr-2 file:cursor-pointer file:rounded-l-lg file:border-0 file:bg-gray-700 file:px-3 file:py-2 file:text-gray-100 focus:border-blue-500 focus:ring-blue-500"
                           required>
                    <button type="submit"
                            class="mt-2 inline-flex w-full items-center justify-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/60 sm:absolute sm:top-0 sm:right-0 sm:mt-0 sm:h-full sm:w-auto sm:rounded-l-none">
                      Upload 
                    </button>
                  </div>
                </form>
              </div>
            <?php else: ?>
              <div class="rounded-lg border border-yellow-700 bg-yellow-900/30 p-4 text-yellow-200">
                Route mapping for “<?php echo e($title); ?>” not found.
              </div>
            <?php endif; ?>
          
        </div>
      </div>

      
      <div id="rename-modal-<?php echo e($idx); ?>-<?php echo e($store->id); ?>" tabindex="-1" aria-hidden="true"
           class="fixed inset-0 z-50 hidden h-[100dvh] w-full items-center justify-center overflow-y-auto overflow-x-hidden p-4">
        <div class="relative w-full max-w-md">
          <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-800">
            <div class="flex items-center justify-between border-b border-gray-200 p-4 dark:border-gray-600">
              <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Update Store Info</h3>
              <button type="button" data-modal-hide="rename-modal-<?php echo e($idx); ?>-<?php echo e($store->id); ?>"
                      class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-200 hover:text-gray-900 focus:outline-none dark:hover:bg-gray-700 dark:hover:text-white">
                <span class="sr-only">Close</span>
                <svg class="h-3 w-3" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <path d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </button>
            </div>
            <div class="p-4">
              <form action="<?php echo e(route('stores.update', $store)); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div>
                  <label for="store_name_<?php echo e($idx); ?>_<?php echo e($store->id); ?>" class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">Store Name</label>
                  <input type="text" id="store_name_<?php echo e($idx); ?>_<?php echo e($store->id); ?>" name="store_name"
                         value="<?php echo e($store->store_name); ?>"
                         class="block w-full rounded-lg border border-gray-300 bg-gray-50 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white" required>
                </div>
                <div>
                  <label for="store_logo_<?php echo e($idx); ?>_<?php echo e($store->id); ?>" class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">Store Logo</label>
                  <input type="file" id="store_logo_<?php echo e($idx); ?>_<?php echo e($store->id); ?>" name="store_logo" accept="image/*"
                         class="block w-full cursor-pointer rounded-lg border border-gray-300 bg-gray-50 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                </div>
                <button type="submit"
                        class="w-full rounded-lg bg-blue-600 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/60">
                  Update
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      
      <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'confirm-store-deletion-'.e($idx).'-'.e($store->id).'','show' => false,'focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'confirm-store-deletion-'.e($idx).'-'.e($store->id).'','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'focusable' => true]); ?>
        <form method="POST" action="<?php echo e(route('stores.destroy', $store->id)); ?>" class="p-6">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <h2 class="text-lg font-medium text-gray-900 dark:text-white">Delete Store</h2>
          <p class="mt-1 text-sm text-gray-600 dark:text-gray-300">
            Once your store is deleted, all associated logs and data will be permanently removed. This action cannot be undone.
          </p>
          <div class="mt-6 flex justify-end">
            <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['xOn:click' => '$dispatch(\'close\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => '$dispatch(\'close\')']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['class' => 'ms-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-3']); ?>Delete Store <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
          </div>
        </form>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>


<div class="mt-4 sm:mt-6" x-data="{ confirmed: false }" x-cloak>
  <div class="sticky bottom-2 sm:static">
    <div class="bg-gray-800/90 backdrop-blur rounded-lg p-3 sm:p-0 flex flex-col items-center sm:bg-transparent">
      <div class="mb-3 flex items-center sm:mb-4">
        <label for="confirm-<?php echo e($idx); ?>" class="ml-2 text-sm text-gray-300">
          If you have already migrated <b class="text-blue-600">"<?php echo e($title); ?>"</b>. Click on the checbox
        </label>
        &nbsp;
        <input
          id="confirm-<?php echo e($idx); ?>"
          type="checkbox"
          class="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"
          x-model="confirmed"
        >
      </div>

      <div class="flex gap-2 sm:gap-3">
        <button
          type="button"
          class="btn-prev rounded-lg bg-gray-700 px-4 py-2 text-gray-200 hover:bg-gray-600 sm:px-6"
          <?php echo e($idx == 1 ? 'disabled' : ''); ?>

        >
          Prev
        </button>

        <button
          type="button"
          class="btn-next rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 sm:px-6"
          :class="{ 'hidden': !confirmed }"
          :disabled="!confirmed"
          aria-disabled="true"
        >
          <?php echo e($idx < 9 ? 'Next' : 'Finish'); ?>

        </button>
      </div>
    </div>
  </div>
</div>

<?php /**PATH C:\xampp\htdocs\CT\wix-migration-app\resources\views/partials/step-box.blade.php ENDPATH**/ ?>