<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 dark:text-white leading-tight">
      <?php echo e(__('Dashboard')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12 bg-gray-100 dark:bg-gray-800">
    <div class="container mx-auto sm:px-6 lg:px-8">
      <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900 dark:text-gray-100">
          <div>

            <?php if(session('success')): ?>
              <div class="my-2 px-4 py-3 rounded bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 border border-green-300 dark:border-green-700">
                <?php echo session('success'); ?>

              </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
              <div class="my-2 px-4 py-3 rounded bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-700">
                <?php echo session('error'); ?>

              </div>
            <?php endif; ?>

            <?php if(count($stores) === 0): ?>
              <div class="my-3 px-4 py-3 rounded bg-yellow-100 dark:bg-yellow-900 text-yellow-900 dark:text-yellow-100 border border-yellow-300 dark:border-yellow-700">
                <b>No Wix stores are connected yet.</b>
                <p class="mt-1 text-sm text-yellow-800 dark:text-yellow-200">
                  To connect, please open this app <b>from your Wix site dashboard</b> (where it will pass the instance token),
                  or use a Wix install/team member invite link.<br><br>
                  <i>Once the app is opened from Wix, your connected store(s) will appear here automatically.</i>
                </p>
              </div>
            <?php else: ?>
              <h4 class="text-3xl text-center mb-5 text-gray-900 dark:text-gray-100">CT Store Migrator</h4>

              <div id="accordion-collapse" class="mb-5" data-accordion="collapse">
                
                <h2 id="accordion-collapse-heading-1">
                  <button type="button"
                          class="flex items-center justify-between w-full p-5 font-medium rtl:text-right text-gray-500 border border-b-0 border-gray-200 rounded-t-xl focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                          data-accordion-target="#accordion-collapse-body-1" aria-expanded="true"
                          aria-controls="accordion-collapse-body-1">
                    <span># Automatic Migration</span>
                    <svg data-accordion-icon class="w-3 h-3 shrink-0 transition-transform duration-200" aria-hidden="true"
                         xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5 5 1 1 5"/>
                    </svg>
                  </button>
                </h2>
                <div id="accordion-collapse-body-1" class="hidden" aria-labelledby="accordion-collapse-heading-1">

                  
                  <div id="auto-wizard" class="mx-auto p-4 sm:p-6 border border-b-0 border-gray-200 dark:border-gray-700">
                    
                    <div class="h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden sm:hidden mb-3">
                      <div class="mobile-progress h-1 bg-blue-600 transition-all duration-300" style="width: 11.11%;"></div>
                    </div>

                    
                    <ol class="stepper flex items-center gap-3 overflow-x-auto snap-x snap-mandatory pb-2
                               text-[13px] sm:text-sm font-medium text-gray-500 dark:text-gray-400">
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="1">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-blue-600 text-white">1</span>
                          <span class="step-label whitespace-nowrap">Categories</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="2">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">2</span>
                          <span class="step-label whitespace-nowrap">Products</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="3">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">3</span>
                          <span class="step-label whitespace-nowrap">Contacts &amp; Members</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="4">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">4</span>
                          <span class="step-label whitespace-nowrap">Orders</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="5">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">5</span>
                          <span class="step-label whitespace-nowrap">Discounts</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="6">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">6</span>
                          <span class="step-label whitespace-nowrap">Coupons</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="7">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">7</span>
                          <span class="step-label whitespace-nowrap">Gift Cards</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="8">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">8</span>
                          <span class="step-label whitespace-nowrap">Loyalty</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1" data-step="9">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">9</span>
                          <span class="step-label whitespace-nowrap">Media</span>
                        </span>
                      </li>
                    </ol>

                    
                    <section class="step-panel" data-step="1">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Categories', 'idx' => 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="2">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Products', 'idx' => 2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="3">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Contacts & Members', 'idx' => 3], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="4">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Orders', 'idx' => 4], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="5">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Discounts', 'idx' => 5], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="6">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Coupons', 'idx' => 6], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="7">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Gift Cards', 'idx' => 7], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="8">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Loyalty', 'idx' => 8], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="9">
                      <?php echo $__env->make('partials.auto-step-box', ['title' => 'Media', 'idx' => 9], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                  </div>
                </div>

                
                <h2 id="accordion-collapse-heading-3">
                  <button type="button"
                          class="flex items-center justify-between w-full p-5 font-medium rtl:text-right text-gray-500 border border-gray-200 rounded-b-sm focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                          data-accordion-target="#accordion-collapse-body-3" aria-expanded="false"
                          aria-controls="accordion-collapse-body-3">
                    <span># Manual Migration</span>
                    <svg data-accordion-icon class="w-3 h-3 shrink-0 transition-transform duration-200" aria-hidden="true"
                         xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5 5 1 1 5"/>
                    </svg>
                  </button>
                </h2>
                <div id="accordion-collapse-body-3" class="hidden" aria-labelledby="accordion-collapse-heading-3">

                  
                  <div id="manual-wizard" class="mx-auto p-4 sm:p-6 border border-b-0 border-gray-200 dark:border-gray-700">
                    
                    <div class="h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden sm:hidden mb-3">
                      <div class="mobile-progress h-1 bg-blue-600 transition-all duration-300" style="width: 11.11%;"></div>
                    </div>

                    
                    <ol class="stepper flex items-center gap-3 overflow-x-auto snap-x snap-mandatory pb-2
                               text-[13px] sm:text-sm font-medium text-gray-500 dark:text-gray-400">
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="1">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-blue-600 text-white">1</span>
                          <span class="step-label whitespace-nowrap">Categories</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="2">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">2</span>
                          <span class="step-label whitespace-nowrap">Products</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="3">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">3</span>
                          <span class="step-label whitespace-nowrap">Contacts &amp; Members</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="4">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">4</span>
                          <span class="step-label whitespace-nowrap">Orders</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="5">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">5</span>
                          <span class="step-label whitespace-nowrap">Discounts</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="6">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">6</span>
                          <span class="step-label whitespace-nowrap">Coupons</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="7">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">7</span>
                          <span class="step-label whitespace-nowrap">Gift Cards</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1 sm:after:content-[''] sm:after:flex-1 sm:after:h-1
                                 sm:after:border-b sm:after:border-gray-200 dark:sm:after:border-gray-700 sm:after:mx-3" data-step="8">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">8</span>
                          <span class="step-label whitespace-nowrap">Loyalty</span>
                        </span>
                      </li>
                      
                      <li class="step-item flex items-center shrink-0 snap-start sm:flex-1" data-step="9">
                        <span class="flex items-center">
                          <span class="step-dot w-7 h-7 mr-2 text-xs flex items-center justify-center rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">9</span>
                          <span class="step-label whitespace-nowrap">Media</span>
                        </span>
                      </li>
                    </ol>

                    
                    <section class="step-panel" data-step="1">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Categories', 'idx' => 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="2">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Products', 'idx' => 2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="3">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Contacts & Members', 'idx' => 3], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="4">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Orders', 'idx' => 4], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="5">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Discounts', 'idx' => 5], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="6">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Coupons', 'idx' => 6], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="7">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Gift Cards', 'idx' => 7], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="8">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Loyalty', 'idx' => 8], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                    <section class="step-panel hidden" data-step="9">
                      <?php echo $__env->make('partials.step-box', ['title' => 'Media', 'idx' => 9], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </section>
                  </div>
                </div>
              </div>
            <?php endif; ?>

            <?php if(!empty($last_accessed_store)): ?>
              <hr>
              <p>
                <b>Last accessed store:</b>
                <?php echo e($last_accessed_store->store_name); ?> (<code><?php echo e(\Illuminate\Support\Str::limit($last_accessed_store->instance_id, 30, '...')); ?></code>)
              </p>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </div>

  
  <script>
    (function () {
      function initWizard(rootId, storageKey) {
        const root = document.getElementById(rootId);
        if (!root) return;

        const panels    = [...root.querySelectorAll('.step-panel')];
        const stepItems = [...root.querySelectorAll('.stepper .step-item')];
        const total     = stepItems.length;
        const mobileBar = root.querySelector('.mobile-progress');

        function updateDots(n) {
          stepItems.forEach(item => {
            const step = +item.dataset.step;
            const dot  = item.querySelector('.step-dot');
            if (!dot) return;
            if (step <= n) {
              dot.classList.remove('bg-gray-200','text-gray-700','dark:bg-gray-700','dark:text-gray-300');
              dot.classList.add('bg-blue-600','text-white');
            } else {
              dot.classList.remove('bg-blue-600','text-white');
              dot.classList.add('bg-gray-200','text-gray-700','dark:bg-gray-700','dark:text-gray-300');
            }
          });
        }

        function showStep(n, { save = true, scroll = true } = {}) {
          n = Math.max(1, Math.min(total, n));
          panels.forEach(p => p.classList.toggle('hidden', p.dataset.step !== String(n)));
          updateDots(n);
          if (mobileBar) mobileBar.style.width = ((n / total) * 100) + '%';
          if (save) localStorage.setItem(`wizard:${storageKey}:step`, String(n));
          if (scroll) stepItems[n-1]?.scrollIntoView({ behavior:'smooth', inline:'center', block:'nearest' });
          root.dataset.currentStep = String(n);
        }

        // Wire controls inside each panel (scoped)
        panels.forEach(panel => {
          const step = +panel.dataset.step;
          const next = panel.querySelector('.btn-next');
          const prev = panel.querySelector('.btn-prev');
          const chk  = panel.querySelector('input[type="checkbox"]');

          chk?.addEventListener('change', () => next?.classList.toggle('hidden', !chk.checked));
          prev?.addEventListener('click', () => showStep(step - 1));
          next?.addEventListener('click', (e) => {
            const isLast = step >= total;

            if (isLast) {
              // optional: reset panels so step 1 looks fresh
              panels.forEach((p, idx) => {
                const c = p.querySelector('input[type="checkbox"]');
                const b = p.querySelector('.btn-next');
                if (c) c.checked = false;
                if (b && idx !== 0) b.classList.add('hidden');
              });

              // jump back to first step (and persist it)
              showStep(1);

              // If your Finish is a plain button (not a form submit), you're done.
              // If it's a form submit and you DON'T want to submit, uncomment:
              // e.preventDefault();

              return;
            }

            // normal next-step flow
            const np = root.querySelector(`.step-panel[data-step="${step+1}"]`);
            if (np) {
              const nChk = np.querySelector('input[type="checkbox"]');
              const nBtn = np.querySelector('.btn-next');
              if (nChk) nChk.checked = false;
              if (nBtn) nBtn.classList.add('hidden');
            }
            showStep(step + 1);
          });

        });

        // Persist current step on ANY form submit within this wizard (so a post/redirect/flash returns to same step)
        root.querySelectorAll('form').forEach(f => {
          f.addEventListener('submit', () => {
            const current = root.dataset.currentStep || '1';
            localStorage.setItem(`wizard:${storageKey}:step`, current);
          });
        });

        // Restore last step (persist across reloads)
        const saved = parseInt(localStorage.getItem(`wizard:${storageKey}:step`) || '1', 10);
        showStep(saved, { save: false, scroll: false });
      }

      // Initialize each section independently
      initWizard('auto-wizard',   'auto');   // Automatic Migration
      initWizard('manual-wizard', 'manual'); // Manual Migration
    })();
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\CT\wix-migration-app\resources\views/dashboard.blade.php ENDPATH**/ ?>