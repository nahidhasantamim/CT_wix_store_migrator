<img src="<?php echo e(asset('logo/logo.webp')); ?>" class="h-16 m-px" alt="CT Migrator" />
<?php /**PATH C:\laragon\www\wix-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>