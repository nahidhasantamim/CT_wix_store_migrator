<?php

namespace App\Http\Controllers;

use App\Helpers\WixHelper;
use App\Models\WixMediaMigration;
use App\Models\WixStore;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class WixMediaController extends Controller
{
    // =========================================================
    // Export Media with Folders
    // =========================================================
    public function exportFolderWithFiles(WixStore $store, Request $request)
    {
        $fromStoreId = $store->instance_id;
        $userId = Auth::id() ?: 1;

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Media', 'Failed to get access token.', 'error');
            return response()->json(['error' => 'You are not authorized to access.'], 401);
        }

        // Fetch all folders (with helper)
        $folders = $this->getWixMediaFolders($accessToken);

        // Add root manually
        $folders[] = [
            'id' => 'media-root',
            'displayName' => 'Root',
            'parentFolderId' => null,
            'createdDate' => null,
            'updatedDate' => null,
            'state' => 'OK',
            'namespace' => 'NO_NAMESPACE'
        ];

        $filesByFolder = [];

        foreach ($folders as $folder) {
            $folderId = $folder['id'];
            $folderName = $folder['displayName'] ?? 'Unnamed';

            try {
                // Fetch files by folder (with helper)
                $files = $this->getWixMediaFilesByFolder($accessToken, $folderId);
                $filesByFolder[$folderId] = $files;

                WixMediaMigration::updateOrCreate([
                    'user_id'     => $userId,
                    'from_store_id' => $fromStoreId,
                    'to_store_id' => null,
                    'folder_id'   => $folderId,
                ], [
                    'folder_name'     => $folderName,
                    'total_files'     => count($files),
                    'imported_files'  => 0,
                    'status'          => 'pending',
                    'error_message'   => null
                ]);
            } catch (\Throwable $e) {
                WixMediaMigration::updateOrCreate([
                    'user_id'     => $userId,
                    'from_store_id' => $fromStoreId,
                    'to_store_id' => null,
                    'folder_id'   => $folderId,
                ], [
                    'folder_name'     => $folderName,
                    'total_files'     => 0,
                    'imported_files'  => 0,
                    'status'          => 'failed',
                    'error_message'   => $e->getMessage()
                ]);
                $filesByFolder[$folderId] = [];
            }
        }

        $data = [
            'from_store_id' => $fromStoreId,
            'folders' => $folders,
            'filesByFolder' => $filesByFolder
        ];

        WixHelper::log('Export Media', "Exported " . count($folders) . " folders with files.", 'success');

        return response()->streamDownload(function () use ($data) {
            echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'media_folder_export.json', [
            'Content-Type' => 'application/json',
        ]);
    }

    // =========================================================
    // Import Media with Folders
    // =========================================================
    public function importFolderWithFiles(Request $request, WixStore $store)
    {
        $userId = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;
        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Media', "Unauthorized: missing access token for store {$toStoreId}", 'error');
            return back()->with('error', 'Unauthorized');
        }

        if (!$request->hasFile('media_json')) {
            WixHelper::log('Import Media', 'No file uploaded (media_json)', 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $json = file_get_contents($request->file('media_json')->getRealPath());
        $data = json_decode($json, true);

        if (!isset($data['folders'], $data['filesByFolder']) || !is_array($data['folders']) || !is_array($data['filesByFolder'])) {
            WixHelper::log('Import Media', 'Invalid JSON: missing folders/filesByFolder keys', 'error');
            return back()->with('error', 'Invalid JSON structure. Required keys: folders and filesByFolder.');
        }

        // Summary counters
        $totalFolders = count($data['folders']);
        $totalFilesPlanned = 0;
        foreach ($data['folders'] as $f) {
            $fid = $f['id'] ?? 'media-root';
            $totalFilesPlanned += count($data['filesByFolder'][$fid] ?? []);
        }

        WixHelper::log(
            'Import Media',
            "Starting import to store {$toStoreId}. Folders: {$totalFolders}, Files: {$totalFilesPlanned}",
            'info'
        );

        // Sort folders by createdDate ascending (nulls last)
        usort($data['folders'], function ($a, $b) {
            $dateA = $a['createdDate'] ?? null;
            $dateB = $b['createdDate'] ?? null;
            if ($dateA === $dateB) return 0;
            if ($dateA === null) return 1;
            if ($dateB === null) return -1;
            return strtotime($dateA) <=> strtotime($dateB);
        });

        $grandImported = 0;
        $grandFailed = 0;

        foreach ($data['folders'] as $folder) {
            $folderId         = $folder['id'] ?? 'media-root';
            $folderName       = $folder['displayName'] ?? 'Unnamed Folder';
            $fromStoreId      = $folder['siteId'] ?? 'unknown';
            $originalFolderId = $folderId;
            $files            = $data['filesByFolder'][$originalFolderId] ?? [];

            $targetFolderId = 'media-root';
            $imported = 0;
            $failed   = [];

            WixHelper::log(
                'Import Media',
                "Folder begin: '{$folderName}' ({$folderId}) | Files: " . count($files),
                'debug'
            );

            // Skip folder creation for media-root
            if ($folderId !== 'media-root') {
                $folderResult = $this->createMediaFolderInWix($accessToken, $folderName);

                if (!isset($folderResult['folder']['id'])) {
                    $err = 'Failed to create folder: ' . json_encode($folderResult);
                    WixHelper::log('Import Media', "Folder create failed for '{$folderName}': {$err}", 'error');

                    WixMediaMigration::updateOrCreate([
                        'user_id'       => $userId,
                        'from_store_id' => $fromStoreId,
                        'folder_id'     => $originalFolderId,
                    ], [
                        'to_store_id'     => $toStoreId,
                        'folder_name'     => $folderName,
                        'total_files'     => count($files),
                        'imported_files'  => 0,
                        'status'          => 'failed',
                        'error_message'   => $err,
                    ]);
                    $grandFailed += count($files);
                    continue;
                }

                $targetFolderId = $folderResult['folder']['id'];
                WixHelper::log(
                    'Import Media',
                    "Folder ensured/created: '{$folderName}' → targetFolderId={$targetFolderId}",
                    'info'
                );
            }

            // Import files
            foreach ($files as $idx => $file) {
                $url         = $file['url'] ?? null;
                $displayName = $file['displayName'] ?? 'Imported_File';
                $mimeType    = $file['mimeType'] ?? null;

                if (!$url) {
                    $failed[] = $displayName;
                    continue;
                }

                try {
                    $importResult = $this->importMediaFileToWix($accessToken, $url, $displayName, $targetFolderId, $mimeType);

                    if (isset($importResult['file']['id'])) {
                        $imported++;
                        if ($imported % 50 === 0) {
                            WixHelper::log(
                                'Import Media',
                                "Folder '{$folderName}': imported {$imported}/" . count($files) . " so far",
                                'debug'
                            );
                        }
                    } else {
                        $failed[] = $displayName;
                    }
                } catch (\Throwable $e) {
                    $failed[] = $displayName;
                    WixHelper::log(
                        'Import Media',
                        "File import exception in '{$folderName}' for '{$displayName}': " . $e->getMessage(),
                        'error'
                    );
                }
            }

            $status = $imported === count($files) ? 'success' : 'failed';

            WixMediaMigration::updateOrCreate([
                'user_id'       => $userId,
                'from_store_id' => $fromStoreId,
                'folder_id'     => $originalFolderId,
            ], [
                'to_store_id'     => $toStoreId,
                'folder_name'     => $folderName,
                'total_files'     => count($files),
                'imported_files'  => $imported,
                'status'          => $status,
                'error_message'   => count($failed) ? json_encode($failed) : null
            ]);

            $grandImported += $imported;
            $grandFailed   += count($failed);

            WixHelper::log(
                'Import Media',
                "Folder end: '{$folderName}' | Imported: {$imported}/" . count($files) . " | Status: {$status}" .
                (count($failed) ? " | Failed: " . count($failed) : ''),
                count($failed) ? 'warn' : 'info'
            );
        }

        WixHelper::log(
            'Import Media',
            "Import completed for store {$toStoreId}. Imported files: {$grandImported}, Failed: {$grandFailed}",
            $grandFailed ? 'warn' : 'success'
        );

        return back()->with('success', 'Media import completed.');
    }



    // =========================================================
    // Utilities
    // =========================================================
    public function getWixMediaFolders($accessToken)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
        ])->get("https://www.wixapis.com/site-media/v1/folders");

        WixHelper::log('Export Media', 'Folders API raw response: ' . $response->body(), 'debug');

        return $response->json('folders') ?? [];
    }

    public function getWixMediaFilesByFolder($accessToken, $folderId)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->get("https://www.wixapis.com/site-media/v1/files", [
            'parentFolderId' => $folderId,
            'paging.limit'   => 100,
        ]);

        WixHelper::log('Export Media', "Files API raw response for folder $folderId: " . $response->body(), 'debug');

        return $response->json('files') ?? [];
    }


    /**
     * Create a folder in Wix Media Manager via API.
     */
    private function createMediaFolderInWix($accessToken, $folderName)
    {
        $body = [
            'displayName' => $folderName,
            'parentFolderId' => 'media-root'
        ];
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->post('https://www.wixapis.com/site-media/v1/folders', $body);

        return $response->json();
    }

    /**
     * Import a media file into Wix Media Manager via API.
     */
    private function importMediaFileToWix($accessToken, $url, $displayName, $parentFolderId, $mimeType = null)
    {
        $body = [
            'url' => $url,
            'displayName' => $displayName,
            'parentFolderId' => $parentFolderId,
            'private' => false,
        ];
        if ($mimeType) {
            $body['mimeType'] = $mimeType;
        }

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->post('https://www.wixapis.com/site-media/v1/files/import', $body);

        return $response->json();
    }

}
