<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\WixStore;
use App\Helpers\WixHelper;
use App\Models\WixOrderMigration;
use Illuminate\Support\Facades\Auth;

class WixOrderController extends Controller
{
    // =========================================================
    // Export Orders
    // =========================================================
    public function export(WixStore $store, Request $request)
    {
        $userId = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Orders', "Export started for store: {$store->store_name} ({$fromStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Orders', "Failed: Could not get access token.", 'error');
            return response()->json(['error' => 'Could not get Wix access token.'], 401);
        }

        // Get all order IDs (paged)
        $orderIds = $this->getWixOrderIds($accessToken);
        if (isset($orderIds['error'])) {
            WixHelper::log('Export Orders', "Order IDs fetch error: " . ($orderIds['raw'] ?? $orderIds['error']), 'error');
            return response()->json(['error' => $orderIds['error']], 500);
        }

        WixHelper::log('Export Orders', "Found " . count($orderIds) . " order IDs to fetch.", 'info');

        $fullOrders = [];
        foreach ($orderIds as $orderId) {
            $order = $this->getWixFullOrder($accessToken, $orderId);
            if (!$order) {
                continue;
            }

            // Upsert a 'pending' row for this export (target unknown at export time)
            WixOrderMigration::updateOrCreate(
                [
                    'user_id'         => $userId,
                    'from_store_id'   => $fromStoreId,
                    'source_order_id' => $order['id'],
                ],
                [
                    'order_number'          => $order['number'] ?? null,
                    'status'                => 'pending',
                    'error_message'         => null,
                    'to_store_id'           => null,
                    'destination_order_id'  => null,
                ]
            );

            $fullOrders[] = $order;
        }

        // Fetch current order settings to export
        $orderSettings = $this->getOrderSettings($accessToken);

        $count = count($fullOrders);
        WixHelper::log('Export Orders', "Exported $count full orders with transactions and fulfillments.", 'success');

        // IMPORTANT: include from_store_id for accurate import-side logging
        $payload = [
            'from_store_id'  => $fromStoreId,
            'orders'         => $fullOrders,
            'orderSettings'  => $orderSettings,
        ];

        return response()->streamDownload(function () use ($payload) {
            echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'orders_with_settings.json', [
            'Content-Type' => 'application/json'
        ]);
    }

    // =========================================================
    // Import Orders
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Orders', "Import started for store: {$store->store_name} ({$toStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Orders', "Failed: Could not get access token.", 'error');
            return back()->with('error', 'Could not get Wix access token.');
        }

        if (!$request->hasFile('orders_json')) {
            WixHelper::log('Import Orders', "No file uploaded.", 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $file = $request->file('orders_json');
        $json = file_get_contents($file->getRealPath());
        $data = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data) || !isset($data['orders'])) {
            WixHelper::log('Import Orders', "Uploaded file is not valid JSON or missing 'orders' key.", 'error');
            return back()->with('error', "Uploaded file is not valid JSON or missing 'orders' key.");
        }

        // Read source store id from payload (added by export); fallback if missing
        $fromStoreId = $data['from_store_id'] ?? 'unknown';

        // Apply order settings if present
        if (isset($data['orderSettings']) && is_array($data['orderSettings'])) {
            $this->updateOrderSettings($accessToken, $data['orderSettings']);
        }

        $orders = $data['orders'];

        // Sort orders by creation date for consistency
        usort($orders, function ($a, $b) {
            return strtotime($a['createdDate'] ?? $a['purchasedDate'] ?? '') <=> strtotime($b['createdDate'] ?? $b['purchasedDate'] ?? '');
        });

        WixHelper::log('Import Orders', "Prepared " . count($orders) . " orders for import from {$fromStoreId} → {$toStoreId}.", 'info');

        $imported = 0;
        $errors = [];
        $processed = 0;

        foreach ($orders as $order) {
            $sourceOrderId = $order['id'] ?? null;
            $orderNumber   = $order['number'] ?? null;

            // Upsert 'pending' record BEFORE attempt (target-aware WHERE keys)
            WixOrderMigration::updateOrCreate(
                [
                    'user_id'          => $userId,
                    'from_store_id'    => $fromStoreId,
                    'to_store_id'      => $toStoreId,
                    'source_order_id'  => $sourceOrderId,
                ],
                [
                    'order_number'          => $orderNumber,
                    'destination_order_id'  => null,
                    'status'                => 'pending',
                    'error_message'         => null,
                ]
            );

            // Backup fulfillments and transactions before removing keys
            $fulfillments = $order['fulfillments']['fulfillments'] ?? [];
            $transactions = $order['transactions']['payments'] ?? [];

            // Remove system fields and normalize order for import
            unset(
                $order['id'], $order['number'], $order['createdDate'], $order['updatedDate'],
                $order['siteLanguage'], $order['isInternalOrderCreate'],
                $order['seenByAHuman'], $order['customFields'],
                $order['transactions'], $order['fulfillments']
            );

            if (!empty($order['lineItems'])) {
                foreach ($order['lineItems'] as &$lineItem) {
                    unset($lineItem['id'], $lineItem['rootCatalogItemId'], $lineItem['priceUndetermined'], $lineItem['fixedQuantity'], $lineItem['modifierGroups']);
                }
                unset($lineItem);
            }

            if (isset($order['activities'])) {
                foreach ($order['activities'] as &$activity) unset($activity['id']);
                unset($activity);
            }

            // Main Order Creation
            $result = $this->createOrderInWix($accessToken, $order);

            if (isset($result['order']['id'])) {
                $imported++;
                $destOrderId = $result['order']['id'];

                // Fulfillment Creation
                foreach ($fulfillments as $fulfillment) {
                    $fulfillmentRes = $this->createFulfillmentInWix($accessToken, $destOrderId, $fulfillment);
                    if (!$fulfillmentRes['success']) {
                        $errors[] = "Fulfillment failed for Order {$orderNumber} ({$destOrderId}): " . $fulfillmentRes['error'];
                    }
                }

                // Payment Addition
                if (!empty($transactions)) {
                    $paymentRes = $this->addPaymentsToOrderInWix($accessToken, $destOrderId, $transactions);
                    if (!$paymentRes['success']) {
                        $errors[] = "Payment import failed for Order {$orderNumber} ({$destOrderId}): " . $paymentRes['error'];
                    }
                }

                // SUCCESS update on the same row
                WixOrderMigration::updateOrCreate(
                    [
                        'user_id'          => $userId,
                        'from_store_id'    => $fromStoreId,
                        'to_store_id'      => $toStoreId,
                        'source_order_id'  => $sourceOrderId,
                    ],
                    [
                        'order_number'          => $orderNumber,
                        'destination_order_id'  => $destOrderId,
                        'status'                => 'success',
                        'error_message'         => null,
                    ]
                );

                WixHelper::log('Import Orders', "Imported order: {$orderNumber} → {$destOrderId}", 'success');
            } else {
                $errMsg = json_encode(['sent' => $order, 'response' => $result]);

                // FAILED update on the same row
                WixOrderMigration::updateOrCreate(
                    [
                        'user_id'          => $userId,
                        'from_store_id'    => $fromStoreId,
                        'to_store_id'      => $toStoreId,
                        'source_order_id'  => $sourceOrderId,
                    ],
                    [
                        'order_number'          => $orderNumber,
                        'destination_order_id'  => null,
                        'status'                => 'failed',
                        'error_message'         => $errMsg,
                    ]
                );

                $errors[] = $errMsg;
                WixHelper::log('Import Orders', "Failed to import order {$orderNumber}: {$errMsg}", 'error');
            }

            $processed++;
            if ($processed % 25 === 0) {
                WixHelper::log('Import Orders', "Progress: {$processed}/".count($orders)." processed; imported={$imported}", 'debug');
            }
        }

        if ($imported > 0) {
            WixHelper::log('Import Orders', "Imported {$imported} order(s)." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""), count($errors) ? 'warning' : 'success');
            return back()->with('success', "{$imported} order(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""));
        } else {
            WixHelper::log('Import Orders', "No orders imported. Errors: " . implode("; ", $errors), 'error');
            return back()->with('error', 'No orders imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));
        }
    }

    // =========================================================
    // Utilities
    // =========================================================
    public function getWixOrderIds($accessToken)
    {
        $query = [
            "sort" => '[{"dateCreated":"asc"}]',
            "paging" => ["limit" => 100, "offset" => 0]
        ];

        $orderIds = [];
        do {
            $body = ['query' => $query];
            $response = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type'  => 'application/json'
            ])->post('https://www.wixapis.com/stores/v2/orders/query', $body);

            if (!$response->ok()) {
                WixHelper::log('Export Orders', 'Failed to fetch order IDs: ' . $response->body(), 'error');
                return ['error' => 'Failed to fetch order IDs from Wix.', 'raw' => $response->body()];
            }

            $data = $response->json();
            $ordersPage = $data['orders'] ?? [];
            foreach ($ordersPage as $orderSummary) {
                if (!empty($orderSummary['id'])) {
                    $orderIds[] = $orderSummary['id'];
                }
            }

            $count = count($ordersPage);
            $query['paging']['offset'] += $count;

            if ($count > 0) {
                WixHelper::log('Export Orders', "Fetched batch of {$count} order IDs (total so far: " . count($orderIds) . ")", 'debug');
            }
        } while ($count > 0);

        return $orderIds;
    }

    public function getWixFullOrder($accessToken, $orderId)
    {
        // Get full order details
        $orderResp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get("https://www.wixapis.com/ecom/v1/orders/{$orderId}");

        if (!$orderResp->ok()) {
            WixHelper::log('Export Orders', "Failed to fetch order {$orderId} details: " . $orderResp->body(), 'error');
            return null;
        }

        $order = $orderResp->json('order');
        if (!$order) return null;

        // Get transactions
        $transactionResp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get("https://www.wixapis.com/ecom/v1/payments/orders/{$orderId}");
        $transactions = $transactionResp->json('orderTransactions') ?? [];

        // Get fulfillments
        $fulfillmentResp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get("https://www.wixapis.com/ecom/v1/fulfillments/orders/{$orderId}");
        $fulfillments = $fulfillmentResp->json('orderWithFulfillments') ?? [];

        $order['transactions'] = $transactions;
        $order['fulfillments'] = $fulfillments;

        return $order;
    }

    public function getOrderSettings($accessToken)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->get('https://www.wixapis.com/ecom/v1/orders-settings');

        if ($response->ok()) {
            return $response->json('ordersSettings');
        }

        WixHelper::log('Orders Settings', 'Failed to fetch orders settings: ' . $response->body(), 'error');
        return null;
    }

    /**
     * Create an order in Wix.
     */
    private function createOrderInWix($accessToken, $order)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/ecom/v1/orders', ['order' => $order]);

        return $response->json();
    }

    /**
     * Create a fulfillment for an order in Wix.
     */
    private function createFulfillmentInWix($accessToken, $orderId, $fulfillment)
    {
        $payload = [
            'fulfillment' => [
                'lineItems'    => $fulfillment['lineItems'] ?? [],
                'trackingInfo' => $fulfillment['trackingInfo'] ?? null,
                'status'       => $fulfillment['status'] ?? 'Fulfilled',
                'completed'    => $fulfillment['completed'] ?? true,
            ]
        ];
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->post("https://www.wixapis.com/ecom/v1/fulfillments/orders/{$orderId}/create-fulfillment", $payload);

        if ($response->ok()) {
            return ['success' => true];
        }
        return ['success' => false, 'error' => $response->body()];
    }

    /**
     * Add payments to an order in Wix.
     */
    private function addPaymentsToOrderInWix($accessToken, $orderId, $transactions)
    {
        $payments = [];
        foreach ($transactions as $payment) {
            $paymentPayload = [
                'amount'         => $payment['amount'] ?? ['amount' => '0.00'],
                'refundDisabled' => $payment['refundDisabled'] ?? false,
            ];

            if (!empty($payment['regularPaymentDetails'])) {
                $paymentPayload['regularPaymentDetails'] = $payment['regularPaymentDetails'];
            } elseif (!empty($payment['giftcardPaymentDetails'])) {
                $paymentPayload['giftcardPaymentDetails'] = $payment['giftcardPaymentDetails'];
            }

            $payments[] = $paymentPayload;
        }

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post("https://www.wixapis.com/ecom/v1/payments/orders/{$orderId}/add-payment", [
            'payments' => $payments,
        ]);

        if ($response->ok()) {
            return ['success' => true];
        }
        return ['success' => false, 'error' => $response->body()];
    }

    public function updateOrderSettings($accessToken, array $settings)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->patch('https://www.wixapis.com/ecom/v1/orders-settings', [
            'ordersSettings' => $settings
        ]);

        if (!$response->ok()) {
            WixHelper::log('Import Orders', 'Failed to update orders settings: ' . $response->body(), 'error');
            return false;
        }

        WixHelper::log('Import Orders', 'Orders settings updated successfully.', 'info');
        return true;
    }
}
