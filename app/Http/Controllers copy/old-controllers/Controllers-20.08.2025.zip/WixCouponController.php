<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use App\Helpers\WixHelper;
use App\Models\WixStore;
use App\Models\WixCouponMigration;

class WixCouponController extends Controller
{
    // =========================================================
    // Export Coupons
    // =========================================================
    public function export(WixStore $store, Request $request)
    {
        $userId      = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Coupons', "Export started for store {$store->store_name} ({$fromStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Coupons', 'Failed to get access token.', 'error');
            return response()->json(['error' => 'You are not authorized to access.'], 401);
        }

        // Fetch coupons
        $resp    = $this->queryCoupons($accessToken);
        $coupons = is_array($resp['coupons'] ?? null) ? $resp['coupons'] : [];
        $count   = count($coupons);

        WixHelper::log('Export Coupons', "Fetched {$count} coupons.", 'info');

        // Save like media-export (overwrite pattern; to_store_id = null; status = pending)
        $saved = 0;
        foreach ($coupons as $coupon) {
            $spec = $coupon['specification'] ?? [];
            $code = $spec['code'] ?? null;
            $name = $spec['name'] ?? null;

            if (!$code) {
                WixHelper::log('Export Coupons', 'Skipped a coupon without specification.code', 'warn');
                continue;
            }

            WixCouponMigration::updateOrCreate(
                [
                    'user_id'            => $userId,
                    'from_store_id'      => $fromStoreId,
                    'to_store_id'        => null,
                    'source_coupon_code' => $code,
                ],
                [
                    'source_coupon_name'    => $name,
                    'destination_coupon_id' => null,
                    'status'                => 'pending',
                    'error_message'         => null,
                ]
            );
            $saved++;
        }

        WixHelper::log('Export Coupons', "Saved {$saved} rows (pending) in wix_coupon_migrations.", 'success');

        // Return download JSON (unchanged behavior)
        return response()->streamDownload(function () use ($coupons) {
            echo json_encode($coupons, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'coupons.json', [
            'Content-Type' => 'application/json',
        ]);
    }

    // =========================================================
    // Import Coupons
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Coupons', "Import started for store {$store->store_name} ({$toStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Coupons', "Unauthorized: missing access token for store {$toStoreId}", 'error');
            return back()->with('error', 'Unauthorized');
        }

        if (!$request->hasFile('coupons_json')) {
            WixHelper::log('Import Coupons', 'No file uploaded (coupons_json)', 'error');
            return back()->with('error', 'No file uploaded.');
        }

        // Optional: allow explicit source store id (to persist in migration rows)
        $explicitFromStoreId = $request->input('from_store_id');

        $json    = file_get_contents($request->file('coupons_json')->getRealPath());
        $coupons = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($coupons)) {
            WixHelper::log('Import Coupons', 'Invalid JSON uploaded.', 'error');
            return back()->with('error', 'Uploaded file is not valid JSON.');
        }

        $total = count($coupons);
        WixHelper::log('Import Coupons', "Parsed {$total} coupon(s) from JSON.", 'info');

        $imported = 0;
        $failed   = 0;
        $errors   = [];

        foreach ($coupons as $coupon) {
            // Clean known system fields that Wix may reject on create
            unset(
                $coupon['id'], $coupon['dateCreated'], $coupon['appId'],
                $coupon['expired'], $coupon['numberOfUsages'], $coupon['displayData']
            );

            $spec = $coupon['specification'] ?? null;
            if (!$spec || !is_array($spec)) {
                $msg = 'Missing specification in coupon: ' . json_encode($coupon);
                $errors[] = $msg;
                WixHelper::log('Import Coupons', $msg, 'error');
                $failed++;
                continue;
            }

            // Normalize scope.group.entityId (Wix rejects empty strings)
            if (isset($spec['scope']['group']['entityId']) && empty($spec['scope']['group']['entityId'])) {
                unset($spec['scope']['group']['entityId']);
            }

            // Minimal fields
            if (empty($spec['code']) || empty($spec['name']) || empty($spec['startTime'])) {
                $msg = 'Missing name/code/startTime for coupon: ' . json_encode($spec);
                $errors[] = $msg;
                WixHelper::log('Import Coupons', $msg, 'error');
                $failed++;
                continue;
            }

            // Best-effort source store id
            $fromStoreId = $explicitFromStoreId ?: ($coupon['siteId'] ?? null);

            // Create coupon in destination
            $response = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type'  => 'application/json',
            ])->post('https://www.wixapis.com/stores/v2/coupons', ['specification' => $spec]);

            $result = $response->json();

            if ($response->ok() && isset($result['id'])) {
                $imported++;
                WixHelper::log('Import Coupons', "Imported coupon {$spec['code']} → {$result['id']}", 'success');

                // Overwrite per unique (user_id, from_store_id, to_store_id, source_coupon_code)
                WixCouponMigration::updateOrCreate(
                    [
                        'user_id'            => $userId,
                        'from_store_id'      => $fromStoreId,
                        'to_store_id'        => $toStoreId,
                        'source_coupon_code' => $spec['code'],
                    ],
                    [
                        'source_coupon_name'    => $spec['name'] ?? null,
                        'destination_coupon_id' => $result['id'],
                        'status'                => 'success',
                        'error_message'         => null,
                    ]
                );
            } else {
                $errPayload = $result ?: $response->body();
                $msg = "Failed to import coupon {$spec['code']}: " . (is_string($errPayload) ? $errPayload : json_encode($errPayload));
                $errors[] = $msg;
                WixHelper::log('Import Coupons', $msg, 'error');
                $failed++;

                WixCouponMigration::updateOrCreate(
                    [
                        'user_id'            => $userId,
                        'from_store_id'      => $fromStoreId,
                        'to_store_id'        => $toStoreId,
                        'source_coupon_code' => $spec['code'],
                    ],
                    [
                        'source_coupon_name'    => $spec['name'] ?? null,
                        'destination_coupon_id' => null,
                        'status'                => 'failed',
                        'error_message'         => is_string($errPayload) ? $errPayload : json_encode($errPayload),
                    ]
                );
            }
        }

        // Final summary log + response
        WixHelper::log(
            'Import Coupons',
            "Import completed for store {$toStoreId}. Imported: {$imported}, Failed: {$failed}",
            $failed ? 'warn' : 'success'
        );

        if ($imported > 0) {
            return back()->with('success', "{$imported} coupon(s) imported.");
        }
        return back()->with('error', 'No coupons imported.');
    }

    // =========================================================
    // Utilities
    // =========================================================
    public function queryCoupons($accessToken, $query = [])
    {
        // Wix API prefers an object for empty query
        if (empty($query)) {
            $query = new \stdClass();
        }
        $body = ['query' => $query];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post('https://www.wixapis.com/stores/v2/coupons/query', $body);

        // Debug raw body for troubleshooting parity with media controller
        WixHelper::log('Export Coupons', 'Coupons API raw response: ' . $response->body(), 'debug');

        if (!$response->ok()) {
            WixHelper::log('Export Coupons', "Query failed: {$response->status()} | {$response->body()}", 'error');
        }

        $json  = $response->json();
        $count = count($json['coupons'] ?? []);
        WixHelper::log('Export Coupons', "Queried coupons API. Status: {$response->status()}, Returned: {$count}", 'info');

        return $json ?: [];
    }
}
