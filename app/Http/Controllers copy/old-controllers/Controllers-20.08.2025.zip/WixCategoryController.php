<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\WixStore;
use App\Helpers\WixHelper;
use App\Models\WixCollectionMigration;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class WixCategoryController extends Controller
{
    // -----------------------------------------
    // Defaults for V3 Categories API
    // -----------------------------------------
    protected string $defaultAppNamespace = '@wix/stores';
    protected ?string $defaultTreeKey = null; // set if you manage multiple trees

    /** Default extra fields to include on V3 export (safe + useful) */
    protected array $defaultExportFieldsV3 = [
        'DESCRIPTION',
        'RICH_CONTENT_DESCRIPTION',
        'SEO_DATA',
        'MANAGING_APP_ID',
        'EXTENDED_FIELDS',
        // 'BREADCRUMBS_INFO', // add if you need breadcrumbs
    ];

    /** System categories we should never try to recreate */
    protected array $systemCategorySlugs = ['all-products'];
    protected array $systemCategoryNames = ['all products', 'all-products'];
    protected array $systemCategoryIds   = ['00000000-000000-000000-000000000001']; // All Products

    // =========================================================
    // Export (auto-detect V1 vs V3)
    // =========================================================
    public function export(WixStore $store)
    {
        $userId      = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Product Categories', "Export started for store: {$store->store_name}", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Product Categories', "Failed: Could not get access token for instanceId: $fromStoreId", 'error');
            return back()->with('error', 'You are not authorized to access.');
        }

        $catalogVersion = WixHelper::getCatalogVersion($accessToken);
        $isV3 = $this->isCatalogV3($catalogVersion);

        if ($isV3) {
            // -------- V3 (Categories API) --------
            $appNamespace = $this->treeAppNamespaceFromRequest();
            $treeKey      = $this->treeKeyFromRequest();
            $fields       = $this->exportFieldsV3FromRequest() ?: $this->defaultExportFieldsV3;

            // Try QUERY first (export-all). If empty, try SEARCH with no expression.
            $result = $this->queryCategoriesV3All(
                $accessToken,
                $fields,
                $appNamespace,
                $treeKey,
                true // returnNonVisibleCategories
            );

            if (empty($result['categories'])) {
                $searchRes = $this->searchCategoriesV3All(
                    $accessToken,
                    $fields,
                    $appNamespace,
                    $treeKey,
                    true // returnNonVisibleCategories
                );
                if (!empty($searchRes['categories'])) {
                    $result = $searchRes;
                }
            }

            if (!isset($result['categories']) || !is_array($result['categories'])) {
                WixHelper::log('Export Product Categories', "V3 API error: " . json_encode($result), 'error');
                return response()->json(['error' => 'Failed to fetch categories from Wix (V3).'], 500);
            }

            foreach ($result['categories'] as $cat) {
                WixCollectionMigration::firstOrCreate([
                    'user_id'               => $userId,
                    'from_store_id'         => $fromStoreId,
                    'to_store_id'           => null,
                    'source_collection_id'  => $cat['id'] ?? null,
                ], [
                    'source_collection_slug' => $cat['slug'] ?? null,
                    'source_collection_name' => $cat['name'] ?? null,
                    'status'                 => 'pending',
                    'error_message'          => null,
                ]);
            }

            $count = count($result['categories']);
            WixHelper::log('Export Product Categories', "Exported and saved $count categories (V3).", 'success');

            return response()->streamDownload(function () use ($result, $fromStoreId, $appNamespace, $treeKey) {
                echo json_encode([
                    'meta' => [
                        'from_store_id'   => $fromStoreId,
                        'tree'            => [
                            'appNamespace' => $appNamespace,
                            'treeKey'      => $treeKey,
                        ],
                        'catalog_version' => 'V3',
                        'generated_at'    => now()->toIso8601String(),
                    ],
                    'categories' => $result['categories'],
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            }, 'categories.json', [
                'Content-Type' => 'application/json'
            ]);

        } else {
            // -------- V1 (keep your current logic) --------
            $collections = $this->getCollectionsFromWixV1($accessToken);

            if (!isset($collections['collections'])) {
                WixHelper::log('Export Collections', "API error: " . json_encode($collections), 'error');
                return response()->json(['error' => 'Failed to fetch collections from Wix (V1).'], 500);
            }

            foreach ($collections['collections'] as $col) {
                WixCollectionMigration::firstOrCreate([
                    'user_id'              => $userId,
                    'from_store_id'        => $fromStoreId,
                    'to_store_id'          => null,
                    'source_collection_id' => $col['id'],
                ], [
                    'source_collection_slug' => $col['slug'] ?? null,
                    'source_collection_name' => $col['name'] ?? null,
                    'status'                 => 'pending',
                    'error_message'          => null,
                ]);
            }

            $count = count($collections['collections']);
            WixHelper::log('Export Collections', "Exported and saved $count collections (V1).", 'success');

            return response()->streamDownload(function () use ($collections, $fromStoreId) {
                echo json_encode([
                    'from_store_id'    => $fromStoreId,
                    'catalog_version'  => 'V1',
                    'collections'      => $collections['collections'],
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            }, 'collections.json', [
                'Content-Type' => 'application/json'
            ]);
        }
    }

    // =========================================================
    // Import (auto-detect V1 vs V3 for the TARGET store)
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Product Categories', "Import started for store: {$store->store_name}", 'info');

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Product Categories', "Failed: Could not get access token for instanceId: {$toStoreId}", 'error');
            return back()->with('error', 'Could not get Wix access token.');
        }

        if (!$request->hasFile('categories_json')) {
            WixHelper::log('Import Product Categories', "No file uploaded for store: {$store->store_name}", 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $json    = file_get_contents($request->file('categories_json')->getRealPath());
        $decoded = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            WixHelper::log('Import Product Categories', "Invalid JSON uploaded.", 'error');
            return back()->with('error', 'Invalid JSON file.');
        }

        // Helpful debug: list top-level keys
        $gotKeys = implode(',', array_keys($decoded));
        WixHelper::log('Import Product Categories', "Uploaded JSON top-level keys: {$gotKeys}", 'debug');

        $catalogVersion = WixHelper::getCatalogVersion($accessToken);
        $isV3 = $this->isCatalogV3($catalogVersion);

        if ($isV3) {
            // -------- V3 IMPORT --------
            $normalized = $this->normalizeUploadedCategories($decoded);
            if ($normalized === null) {
                WixHelper::log(
                    'Import Product Categories',
                    'Invalid JSON structure. Expect one of: ' .
                    '{"meta": {"from_store_id": "..."},"categories":[...] }  OR  ' .
                    '{"from_store_id":"...","collections":[...] }',
                    'error'
                );
                return back()->with('error',
                    'Invalid JSON. Provide V3 export (meta.from_store_id + categories[]) or V1 export (from_store_id + collections[]).'
                );
            }

            [$fromStoreId, $categories] = $normalized;

            $appNamespace = $this->treeAppNamespaceFromRequest();
            $treeKey      = $this->treeKeyFromRequest();

            $imported = 0;
            $errors   = [];

            // Build a set of existing slugs to avoid collisions up front
            $existingSlugs = $this->getExistingSlugsV3($accessToken, $appNamespace, $treeKey);

            foreach ($categories as $category) {
                $sourceId = $category['id'] ?? null;
                if (!$sourceId) continue;

                // Skip built-in/system categories (e.g., All Products)
                if ($this->shouldSkipSystemCategory($category)) {
                    WixHelper::log('Import Product Categories', "Skipped system category '{$category['name']}'", 'info');

                    WixCollectionMigration::updateOrCreate(
                        [
                            'user_id'              => $userId,
                            'from_store_id'        => $fromStoreId,
                            'source_collection_id' => $sourceId,
                        ],
                        [
                            'to_store_id'               => $toStoreId,
                            'source_collection_slug'    => $category['slug'] ?? null,
                            'source_collection_name'    => $category['name'] ?? null,
                            'destination_collection_id' => null,
                            'status'                    => 'skipped',
                            'error_message'             => null,
                        ]
                    );
                    continue;
                }

                $migration = WixCollectionMigration::where([
                    'user_id'              => $userId,
                    'from_store_id'        => $fromStoreId,
                    'source_collection_id' => $sourceId,
                ])->first();

                if ($migration && $migration->status === 'success') {
                    continue;
                }

                // Prepare payload
                $payloadCategory = $this->sanitizeCategoryForCreateV3($category);

                // Ensure a unique slug BEFORE call
                $baseForSlug = $payloadCategory['slug'] ?? ($category['slug'] ?? $category['name'] ?? 'category');
                $payloadCategory['slug'] = $this->makeUniqueSlug($baseForSlug, $existingSlugs);

                // Create with retry on DUPLICATE_SLUG (race condition safety)
                $result = $this->createCategoryWithDedupeV3(
                    $accessToken,
                    $payloadCategory,
                    $appNamespace,
                    $treeKey,
                    $existingSlugs
                );

                if (isset($result['category']['id'])) {
                    $imported++;

                    WixCollectionMigration::updateOrCreate(
                        [
                            'user_id'              => $userId,
                            'from_store_id'        => $fromStoreId,
                            'source_collection_id' => $sourceId,
                        ],
                        [
                            'to_store_id'               => $toStoreId,
                            'source_collection_slug'    => $category['slug'] ?? null,
                            'source_collection_name'    => $category['name'] ?? null,
                            'destination_collection_id' => $result['category']['id'],
                            'status'                    => 'success',
                            'error_message'             => null,
                        ]
                    );

                    WixHelper::log('Import Product Categories', "V3 Imported '{$payloadCategory['name']}' (new ID: {$result['category']['id']})", 'success');
                } else {
                    $errorMsg = json_encode([
                        'sent'     => ['category' => $payloadCategory, 'treeReference' => $this->treeRefArray($appNamespace, $treeKey)],
                        'response' => $result
                    ]);
                    $errors[] = $errorMsg;

                    WixCollectionMigration::updateOrCreate(
                        [
                            'user_id'              => $userId,
                            'from_store_id'        => $fromStoreId,
                            'source_collection_id' => $sourceId,
                        ],
                        [
                            'to_store_id'               => $toStoreId,
                            'source_collection_slug'    => $category['slug'] ?? null,
                            'source_collection_name'    => $category['name'] ?? null,
                            'status'                    => 'failed',
                            'error_message'             => $errorMsg,
                        ]
                    );

                    WixHelper::log('Import Product Categories', "V3 Failed to import '{$payloadCategory['name']}' " . json_encode($result), 'error');
                }
            }

            if ($imported > 0) {
                WixHelper::log('Import Product Categories', "V3 Import finished: $imported category(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""), 'success');
                return back()->with('success', "$imported category(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""));
            }

            WixHelper::log('Import Product Categories', "V3 No categories imported. Errors: " . implode("; ", $errors), 'error');
            return back()->with('error', 'No categories imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));

        } else {
            // -------- V1 IMPORT (keep current behavior) --------
            if (!isset($decoded['from_store_id'], $decoded['collections']) || !is_array($decoded['collections'])) {
                WixHelper::log('Import Collections', "Invalid JSON structure for V1 import. Expect keys: from_store_id, collections[].", 'error');
                return back()->with('error', 'Invalid JSON structure. Required keys: from_store_id and collections[].');
            }

            $fromStoreId = $decoded['from_store_id'];
            $collections = $decoded['collections'];

            $imported = 0;
            $errors   = [];

            foreach ($collections as $collection) {
                $sourceId = $collection['id'] ?? null;
                if (!$sourceId) continue;

                // Skip built-in/system collection (e.g., All Products)
                if ($this->shouldSkipSystemCategory($collection)) {
                    WixHelper::log('Import Collections', "Skipped system collection '{$collection['name']}'", 'info');

                    WixCollectionMigration::updateOrCreate(
                        [
                            'user_id'              => $userId,
                            'from_store_id'        => $fromStoreId,
                            'source_collection_id' => $sourceId,
                        ],
                        [
                            'to_store_id'               => $toStoreId,
                            'source_collection_slug'    => $collection['slug'] ?? null,
                            'source_collection_name'    => $collection['name'] ?? null,
                            'destination_collection_id' => null,
                            'status'                    => 'skipped',
                            'error_message'             => null,
                        ]
                    );
                    continue;
                }

                $migration = WixCollectionMigration::where([
                    'user_id'              => $userId,
                    'from_store_id'        => $fromStoreId,
                    'source_collection_id' => $sourceId,
                ])->first();

                if ($migration && $migration->status === 'success') {
                    continue;
                }

                // Clean up system fields before V1 import
                unset($collection['id'], $collection['slug'], $collection['numberOfProducts']);

                $result = $this->createCollectionInWixV1($accessToken, $collection);

                if (isset($result['collection']['id'])) {
                    $imported++;

                    WixCollectionMigration::updateOrCreate([
                        'user_id'              => $userId,
                        'from_store_id'        => $fromStoreId,
                        'source_collection_id' => $sourceId,
                    ], [
                        'to_store_id'               => $toStoreId,
                        'source_collection_slug'    => $collection['slug'] ?? null,
                        'source_collection_name'    => $collection['name'] ?? null,
                        'destination_collection_id' => $result['collection']['id'],
                        'status'                    => 'success',
                        'error_message'             => null,
                    ]);

                    WixHelper::log('Import Collections', "Imported collection '{$collection['name']}' (new ID: {$result['collection']['id']})", 'success');
                } else {
                    $errorMsg = json_encode(['sent' => $collection, 'response' => $result]);
                    $errors[] = $errorMsg;

                    WixCollectionMigration::updateOrCreate([
                        'user_id'              => $userId,
                        'from_store_id'        => $fromStoreId,
                        'source_collection_id' => $sourceId,
                    ], [
                        'to_store_id'               => $toStoreId,
                        'source_collection_slug'    => $collection['slug'] ?? null,
                        'source_collection_name'    => $collection['name'] ?? null,
                        'status'                    => 'failed',
                        'error_message'             => $errorMsg,
                    ]);

                    WixHelper::log('Import Collections', "Failed to import '{$collection['name']}' " . json_encode($result), 'error');
                }
            }

            if ($imported > 0) {
                WixHelper::log('Import Collections', "Import finished: $imported collection(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""), 'success');
                return back()->with('success', "$imported collection(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""));
            }

            WixHelper::log('Import Collections', "No collections imported. Errors: " . implode("; ", $errors), 'error');
            return back()->with('error', 'No collections imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));
        }
    }

    // =========================================================
    // Helpers: request-driven overrides for V3 tree + fields
    // =========================================================
    protected function treeAppNamespaceFromRequest(): string
    {
        $val = request()->query('appNamespace', $this->defaultAppNamespace);
        return trim($val) !== '' ? $val : $this->defaultAppNamespace;
    }

    protected function treeKeyFromRequest(): ?string
    {
        $tk = request()->query('treeKey', $this->defaultTreeKey);
        return ($tk !== null && trim((string)$tk) !== '') ? $tk : null;
    }

    protected function exportFieldsV3FromRequest(): array
    {
        $fromQuery = request()->query('fields');
        if ($fromQuery) {
            return array_values(array_filter(array_map('trim', explode(',', $fromQuery))));
        }
        return [];
    }

    // =========================================================
    // V3 Utilities (Categories API)
    // =========================================================

    /** Detect if catalogVersion implies V3 */
    protected function isCatalogV3(?string $catalogVersion): bool
    {
        if (!$catalogVersion) return false;
        $v = strtoupper(preg_replace('/[^A-Z0-9_]/', '', $catalogVersion));
        // Handles values like "V3", "V3_CATALOG", "CATALOG_V3" etc.
        return str_contains($v, 'V3');
    }

    /**
     * Query all categories (V3) with paging
     */
    protected function queryCategoriesV3All(
        string $accessToken,
        array $fields,
        string $appNamespace,
        ?string $treeKey,
        bool $returnNonVisible = true
    ): array {
        $all = [];
        $cursor = null;

        do {
            $body = [
                'query' => [
                    'cursorPaging' => ['limit' => 1000],
                ],
                'treeReference' => $this->treeRefArray($appNamespace, $treeKey),
            ];

            if (!empty($fields)) {
                $body['fields'] = $fields;
            }
            if ($returnNonVisible) {
                $body['returnNonVisibleCategories'] = true;
            }
            if ($cursor) {
                $body['query']['cursorPaging']['cursor'] = $cursor;
            }

            $response = Http::withHeaders([
                'Authorization' => $this->ensureBearer($accessToken),
                'Content-Type'  => 'application/json'
            ])->post('https://www.wixapis.com/categories/v1/categories/query', $body);

            WixHelper::log('Export Product Categories', 'V3 QUERY page raw: ' . $response->body(), 'debug');

            $json = $response->json();
            if (!isset($json['categories']) || !is_array($json['categories'])) {
                return ['categories' => $all, 'error' => $json];
            }

            $all = array_merge($all, $json['categories']);
            $cursor = $json['pagingMetadata']['cursors']['next'] ?? null;
        } while ($cursor);

        return ['categories' => $all];
    }

    /**
     * Search all categories (V3) with paging (free-text optional)
     */
    protected function searchCategoriesV3All(
        string $accessToken,
        array $fields,
        string $appNamespace,
        ?string $treeKey,
        bool $returnNonVisible = true,
        ?string $expression = null
    ): array {
        $all = [];
        $cursor = null;

        do {
            $searchNode = [
                'cursorPaging' => ['limit' => 1000],
            ];
            if ($expression !== null && trim($expression) !== '') {
                $searchNode['search'] = ['expression' => $expression];
            }

            $body = [
                'search' => $searchNode,
                'treeReference' => $this->treeRefArray($appNamespace, $treeKey),
            ];

            if (!empty($fields)) {
                $body['fields'] = $fields;
            }
            if ($returnNonVisible) {
                $body['returnNonVisibleCategories'] = true;
            }
            if ($cursor) {
                $body['search']['cursorPaging']['cursor'] = $cursor;
            }

            $response = Http::withHeaders([
                'Authorization' => $this->ensureBearer($accessToken),
                'Content-Type'  => 'application/json'
            ])->post('https://www.wixapis.com/categories/v1/categories/search', $body);

            WixHelper::log('Export Product Categories', 'V3 SEARCH page raw: ' . $response->body(), 'debug');

            $json = $response->json();
            if (!isset($json['categories']) || !is_array($json['categories'])) {
                return ['categories' => $all, 'error' => $json];
            }

            $all = array_merge($all, $json['categories']);
            $cursor = $json['pagingMetadata']['cursors']['next'] ?? null;
        } while ($cursor);

        return ['categories' => $all];
    }

    /** Create category (V3) */
    protected function createCategoryInWixV3(string $accessToken, array $category, string $appNamespace, ?string $treeKey): array
    {
        $body = [
            'category'      => $category,
            'treeReference' => $this->treeRefArray($appNamespace, $treeKey),
        ];

        $response = Http::withHeaders([
            'Authorization' => $this->ensureBearer($accessToken),
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/categories/v1/categories', $body);

        return $response->json();
    }

    /** Build treeReference for V3 */
    protected function treeRefArray(string $appNamespace, ?string $treeKey): array
    {
        $ref = ['appNamespace' => $appNamespace];
        if ($treeKey !== null) {
            $ref['treeKey'] = $treeKey;
        }
        return $ref;
    }

    /**
     * Sanitize category for V3 create:
     * - Remove response/system fields
     * - Keep safe fields (name, slug, description, image, visible, seoData, richContentDescription)
     * - Parent mapping omitted (imports under root) — add mapping if you want hierarchy
     */
    protected function sanitizeCategoryForCreateV3(array $category): array
    {
        $payload = $category;

        unset(
            $payload['id'],
            $payload['managingAppId'],
            $payload['extendedFields'],
            $payload['treeReference']
        );

        // Import under root for safety (no parent mapping in this pass)
        if (isset($payload['parentCategory'])) {
            unset($payload['parentCategory']);
        }

        // Ensure name exists
        $payload['name'] = trim($payload['name'] ?? '');

        // Image clean
        if (isset($payload['image'])) {
            $img = $payload['image'];
            $clean = [];
            if (!empty($img['id']))      $clean['id'] = $img['id'];
            if (!empty($img['url']))     $clean['url'] = $img['url'];
            if (!empty($img['altText'])) $clean['altText'] = $img['altText'];
            if ($clean) $payload['image'] = $clean; else unset($payload['image']);
        }

        // Keep slug if non-empty, else let Wix generate
        if (isset($payload['slug'])) {
            $payload['slug'] = trim($payload['slug']);
            if ($payload['slug'] === '') unset($payload['slug']);
        }

        // Keep 'visible', 'description', 'richContentDescription', 'seoData' if present
        return $payload;
    }

    /**
     * Optional: get the "All Products" category id (V3).
     */
    protected function getAllProductsCategoryIdV3(string $accessToken): ?string
    {
        $response = Http::withHeaders([
            'Authorization' => $this->ensureBearer($accessToken),
            'Content-Type'  => 'application/json'
        ])->get('https://www.wixapis.com/stores/v3/all-products-category');

        if ($response->ok()) {
            $json = $response->json();
            return $json['categoryId'] ?? null;
        }
        return null;
    }

    /** Return a set (assoc array) of existing slugs in the target store (V3). */
    protected function getExistingSlugsV3(string $accessToken, ?string $appNamespace, ?string $treeKey): array
    {
        $set = [];
        $res = $this->queryCategoriesV3All(
            $accessToken,
            [], // no extra fields needed for slugs
            $appNamespace ?: $this->defaultAppNamespace,
            $treeKey,
            true
        );
        if (empty($res['categories'])) {
            // fallback to SEARCH in case QUERY returned empty for this site
            $res = $this->searchCategoriesV3All(
                $accessToken,
                [],
                $appNamespace ?: $this->defaultAppNamespace,
                $treeKey,
                true
            );
        }
        foreach (($res['categories'] ?? []) as $cat) {
            if (!empty($cat['slug'])) {
                $set[strtolower($cat['slug'])] = true;
            }
        }
        return $set;
    }

    /** Decide if a category should be skipped (system/built-in etc). */
    protected function shouldSkipSystemCategory(array $category): bool
    {
        $id   = strtolower((string)($category['id'] ?? ''));
        $slug = strtolower((string)($category['slug'] ?? ''));
        $name = strtolower((string)($category['name'] ?? ''));

        if ($id && in_array($id, array_map('strtolower', $this->systemCategoryIds), true)) {
            return true;
        }
        if ($slug && in_array($slug, $this->systemCategorySlugs, true)) {
            return true;
        }
        if ($name && in_array($name, $this->systemCategoryNames, true)) {
            return true;
        }
        return false;
    }

    /** Make a unique slug given existing ones; mutates $existing to include the chosen slug. */
    protected function makeUniqueSlug(string $base, array &$existing): string
    {
        $base = trim($base) !== '' ? Str::slug($base) : 'category';
        $candidate = $base;
        $i = 2;
        while (isset($existing[strtolower($candidate)])) {
            $candidate = $base . '-' . $i;
            $i++;
            if ($i > 9999) break; // safety
        }
        $existing[strtolower($candidate)] = true;
        return $candidate;
    }

    /**
     * Try to create; if DUPLICATE_SLUG is returned (race condition),
     * bump slug and retry up to $maxRetries.
     */
    protected function createCategoryWithDedupeV3(
        string $accessToken,
        array $payloadCategory,
        string $appNamespace,
        ?string $treeKey,
        array &$existingSlugs,
        int $maxRetries = 3
    ): array {
        $attempt = 0;
        do {
            $result = $this->createCategoryInWixV3($accessToken, $payloadCategory, $appNamespace, $treeKey);
            $attempt++;

            // success
            if (isset($result['category']['id'])) {
                return $result;
            }

            // duplicate slug -> choose a new one and retry
            $code = $result['details']['applicationError']['code'] ?? null;
            if ($code === 'DUPLICATE_SLUG') {
                $current = $payloadCategory['slug'] ?? ($payloadCategory['name'] ?? 'category');
                $payloadCategory['slug'] = $this->makeUniqueSlug($current, $existingSlugs);
                continue;
            }

            // other error -> bail
            return $result;

        } while ($attempt <= $maxRetries);

        return $result;
    }

    // =========================================================
    // V1 Utilities (kept as-is)
    // =========================================================
    protected function getCollectionsFromWixV1(string $accessToken): array
    {
        $body = ['query' => new \stdClass()];

        $response = Http::withHeaders([
            'Authorization' => $this->ensureBearer($accessToken),
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/stores-reader/v1/collections/query', $body);

        WixHelper::log('Export Collections', 'Wix API raw response: ' . $response->body(), 'debug');

        return $response->json();
    }

    protected function createCollectionInWixV1(string $accessToken, array $collection): array
    {
        $body = ['collection' => $collection];

        $response = Http::withHeaders([
            'Authorization' => $this->ensureBearer($accessToken),
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/stores/v1/collections', $body);

        return $response->json();
    }

    // =========================================================
    // Normalization for uploaded files (V3 importer)
    // =========================================================

    /**
     * Normalize uploaded JSON into a tuple: [fromStoreId, categories[]]
     * Supports:
     *  - V3 export: { meta: { from_store_id }, categories: [...] }
     *  - V1 export: { from_store_id, collections: [...] }  -> mapped into categories
     *  - Hybrid:     { from_store_id, categories: [...] }
     *
     * Returns null if shape is unrecognized.
     */
    protected function normalizeUploadedCategories(array $decoded): ?array
    {
        // V3 export (preferred)
        if (isset($decoded['categories']) && is_array($decoded['categories'])) {
            $from = $decoded['meta']['from_store_id'] ?? ($decoded['from_store_id'] ?? null);
            if ($from !== null) {
                return [$from, $decoded['categories']];
            }
        }

        // V1 export -> convert collections[] => categories[]
        if (isset($decoded['collections']) && is_array($decoded['collections']) && isset($decoded['from_store_id'])) {
            $from = $decoded['from_store_id'];

            $categories = array_map(function ($col) {
                // Keep the original id so migration mapping still works.
                $cat = [
                    'id'      => $col['id']   ?? null,
                    'name'    => $col['name'] ?? '',
                ];

                if (!empty($col['slug']))        $cat['slug'] = $col['slug'];
                if (!empty($col['description'])) $cat['description'] = $col['description'];
                if (array_key_exists('visible', $col)) $cat['visible'] = (bool)$col['visible'];

                // Pull image from V1 media structure
                if ($img = $this->extractImageFromV1Collection($col)) {
                    $cat['image'] = $img; // { url, altText? }
                }

                // Default to root; add parent mapping in a second pass if needed
                return $cat;
            }, $decoded['collections']);

            return [$from, $categories];
        }

        // Hybrid: { from_store_id, categories: [...] }
        if (isset($decoded['from_store_id']) && isset($decoded['categories']) && is_array($decoded['categories'])) {
            return [$decoded['from_store_id'], $decoded['categories']];
        }

        return null;
    }

    // =========================================================
    // V1 media -> V3 image helpers
    // =========================================================

    /**
     * Safe nested array getter.
     */
    protected function getNested(array $arr, array $path)
    {
        $cur = $arr;
        foreach ($path as $key) {
            if (is_int($key)) {
                if (!isset($cur[$key])) return null;
                $cur = $cur[$key];
            } else {
                if (!isset($cur[$key])) return null;
                $cur = $cur[$key];
            }
        }
        return $cur;
    }

    /**
     * Extract a usable image payload from a V1 collection shape.
     * Prefers mainMedia.image.url, falls back to mainMedia.thumbnail.url, then first items[].
     */
    protected function extractImageFromV1Collection(array $col): ?array
    {
        $candidates = [
            ['media','mainMedia','image','url'],
            ['media','mainMedia','thumbnail','url'],
            ['media','items',0,'image','url'],
            ['media','items',0,'thumbnail','url'],
        ];

        foreach ($candidates as $path) {
            $url = $this->getNested($col, $path);
            if (is_string($url) && trim($url) !== '') {
                $img = ['url' => $url];
                if (!empty($col['name'])) {
                    $img['altText'] = $col['name'];
                }
                return $img;
            }
        }
        return null;
    }

    // =========================================================
    // Misc helpers
    // =========================================================
    protected function ensureBearer(string $token): string
    {
        return str_starts_with($token, 'Bearer ') ? $token : ('Bearer '.$token);
    }
}
