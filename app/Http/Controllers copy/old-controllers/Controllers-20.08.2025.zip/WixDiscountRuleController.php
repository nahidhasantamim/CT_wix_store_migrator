<?php

namespace App\Http\Controllers;

use App\Models\WixDiscountRule;
use App\Models\WixDiscountRuleMigration;
use App\Models\WixStore;
use App\Helpers\WixHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class WixDiscountRuleController extends Controller
{
    // =========================================================
    // Export Discount Rules
    // =========================================================
    public function export(WixStore $store)
    {
        $userId      = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Discount Rules', "Export started for store: {$store->store_name} ({$fromStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Discount Rules', "Failed to get access token.", 'error');
            return response()->json(['error' => 'You are not authorized to access.'], 401);
        }

        // Fetch from Wix
        $resp = $this->getDiscountRulesFromWix($accessToken);

        if (!isset($resp['discountRules']) || !is_array($resp['discountRules'])) {
            WixHelper::log('Export Discount Rules', "API error: " . json_encode($resp), 'error');
            return response()->json(['error' => 'Failed to fetch discount rules from Wix.'], 500);
        }

        $rules = $resp['discountRules'];
        $count = count($rules);
        WixHelper::log('Export Discount Rules', "Fetched {$count} discount rule(s).", 'info');

        // Persist "pending" (overwrite pattern; to_store_id = null)
        $saved = 0;
        foreach ($rules as $rule) {
            $sourceId = $rule['id']   ?? null;
            $ruleName = $rule['name'] ?? null;
            if (!$sourceId) {
                WixHelper::log('Export Discount Rules', 'Skipped a rule with no id', 'warn');
                continue;
            }

            WixDiscountRuleMigration::updateOrCreate(
                [
                    'user_id'        => $userId,
                    'from_store_id'  => $fromStoreId,
                    'to_store_id'    => null,          // export phase
                    'source_rule_id' => $sourceId,
                ],
                [
                    'source_rule_name'       => $ruleName,
                    'destination_rule_id'    => null,
                    'status'                 => 'pending',
                    'error_message'          => null,
                ]
            );
            $saved++;
        }

        WixHelper::log('Export Discount Rules', "Saved {$saved} pending row(s) to wix_discount_rule_migrations.", 'success');

        // Download JSON (same structure as before)
        return response()->streamDownload(function () use ($rules, $fromStoreId) {
            echo json_encode([
                'from_store_id' => $fromStoreId,
                'discountRules' => $rules,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'discount_rules.json', [
            'Content-Type' => 'application/json',
        ]);
    }

    // =========================================================
    // Import Discount Rules
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Discount Rules', "Import started for store: {$store->store_name} ({$toStoreId})", 'info');

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Discount Rules', "Failed to get access token.", 'error');
            return back()->with('error', 'Unauthorized');
        }

        if (!$request->hasFile('discount_rules_json')) {
            WixHelper::log('Import Discount Rules', "No file uploaded.", 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $file    = $request->file('discount_rules_json');
        $json    = file_get_contents($file->getRealPath());
        $decoded = json_decode($json, true);

        if (!isset($decoded['from_store_id'], $decoded['discountRules']) || !is_array($decoded['discountRules'])) {
            WixHelper::log('Import Discount Rules', "Invalid JSON format.", 'error');
            return back()->with('error', 'Invalid JSON. Required keys: from_store_id and discountRules.');
        }

        $fromStoreId = $decoded['from_store_id'];
        $rules       = $decoded['discountRules'];
        $total       = count($rules);
        $imported    = 0;
        $errors      = [];

        WixHelper::log('Import Discount Rules', "Starting import to store {$toStoreId}. Rules: {$total}", 'info');

        $processed = 0;

        foreach ($rules as $rule) {
            $processed++;

            $sourceId = $rule['id']   ?? null;
            $ruleName = $rule['name'] ?? null;
            if (!$sourceId) {
                $errors[] = "Rule missing id: " . json_encode($rule);
                WixHelper::log('Import Discount Rules', "Rule missing id.", 'error');
                continue;
            }

            // Target-aware skip: only skip if already success for THIS destination
            $existing = WixDiscountRuleMigration::where([
                'user_id'        => $userId,
                'from_store_id'  => $fromStoreId,
                'to_store_id'    => $toStoreId,
                'source_rule_id' => $sourceId,
            ])->first();

            if ($existing && $existing->status === 'success') {
                WixHelper::log('Import Discount Rules', "Skip already-imported for target {$toStoreId}: '{$ruleName}' ({$sourceId})", 'debug');
                continue;
            }

            // Remove system id before create
            unset($rule['id']);

            // Create in target
            $result   = $this->createDiscountRuleInWix($accessToken, $rule);
            $createdId = $result['discountRule']['id'] ?? null;

            if ($createdId) {
                $imported++;

                WixDiscountRuleMigration::updateOrCreate([
                    'user_id'        => $userId,
                    'from_store_id'  => $fromStoreId,
                    'to_store_id'    => $toStoreId,     // include target in the key (overwrite pattern)
                    'source_rule_id' => $sourceId,
                ], [
                    'source_rule_name'     => $ruleName,
                    'destination_rule_id'  => $createdId,
                    'status'               => 'success',
                    'error_message'        => null,
                ]);

                WixHelper::log('Import Discount Rules', "Imported rule '{$ruleName}' (new ID: {$createdId})", 'success');
            } else {
                $errorMsg = json_encode(['sent' => $rule, 'response' => $result]);

                WixDiscountRuleMigration::updateOrCreate([
                    'user_id'        => $userId,
                    'from_store_id'  => $fromStoreId,
                    'to_store_id'    => $toStoreId,     // include target in the key (overwrite pattern)
                    'source_rule_id' => $sourceId,
                ], [
                    'source_rule_name'     => $ruleName,
                    'destination_rule_id'  => null,
                    'status'               => 'failed',
                    'error_message'        => $errorMsg,
                ]);

                $errors[] = $errorMsg;
                WixHelper::log('Import Discount Rules', "Failed to import '{$ruleName}': {$errorMsg}", 'error');
            }

            // Optional progress log every 50 rules (like your media files)
            if ($processed % 50 === 0) {
                WixHelper::log('Import Discount Rules', "Progress: {$processed}/{$total}", 'debug');
            }
        }

        // Final summary
        $suffix = count($errors) ? " (with " . count($errors) . " error(s))" : '';
        WixHelper::log('Import Discount Rules', "Import completed for store {$toStoreId}. Imported: {$imported}/{$total}{$suffix}", count($errors) ? 'warn' : 'success');

        if ($imported > 0) {
            return back()->with('success', "{$imported} rule(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""));
        }
        return back()->with('error', 'No discount rules imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));
    }

    // =========================================================
    // Utilities
    // =========================================================
    public function getDiscountRulesFromWix($accessToken)
    {
        $query = [
            'query' => [
                'sort' => [['fieldName' => 'name', 'order' => 'ASC']],
                'cursorPaging' => ['limit' => 100],
            ],
        ];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post('https://www.wixapis.com/ecom/v1/discount-rules/query', $query);

        WixHelper::log('Export Discount Rules', 'Wix API raw response: ' . $response->body(), 'debug');

        if (!$response->ok()) {
            WixHelper::log('Export Discount Rules', "Query failed: {$response->status()} | {$response->body()}", 'error');
        }

        return $response->json();
    }

    private function createDiscountRuleInWix($accessToken, $rule)
    {
        $body = ['discountRule' => $rule];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post('https://www.wixapis.com/ecom/v1/discount-rules', $body);

        // Keep raw body for parity with media-style debugging if needed
        if (!$response->ok()) {
            WixHelper::log('Import Discount Rules', "Create failed: {$response->status()} | {$response->body()}", 'warn');
        }

        return $response->json();
    }
}
