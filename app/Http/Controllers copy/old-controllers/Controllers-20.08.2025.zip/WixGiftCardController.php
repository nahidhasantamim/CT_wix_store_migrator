<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\WixStore;
use App\Helpers\WixHelper;
use App\Models\WixGiftCardMigration;
use Illuminate\Support\Facades\Auth;

class WixGiftCardController extends Controller
{
    // =========================================================
    // Export Gift Cards
    // =========================================================
    public function export(WixStore $store)
    {
        $userId      = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Gift Cards', "Export started for store: {$store->store_name}", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Gift Cards', "Failed: Could not get access token for instanceId: $fromStoreId", 'error');
            return back()->with('error', 'You are not authoraized to access.');
        }

        $result = $this->getGiftCardsFromWix($accessToken);

        if (!isset($result['giftCards']) || !is_array($result['giftCards'])) {
            WixHelper::log('Export Gift Cards', "API error: " . json_encode($result), 'error');
            return response()->json(['error' => 'Failed to fetch gift cards from Wix.'], 500);
        }

        foreach ($result['giftCards'] as $gc) {
            WixGiftCardMigration::firstOrCreate(
                [
                    'user_id'             => $userId,
                    'from_store_id'       => $fromStoreId,
                    'to_store_id'         => null,
                    'source_gift_card_id' => $gc['id'] ?? null,
                ],
                [
                    // Wix returns obfuscated code in query/get; keep for reference only
                    'source_code_suffix'   => $gc['code'] ?? null,
                    'initial_value_amount' => $gc['initialValue']['amount'] ?? null,
                    'currency'             => $gc['currency'] ?? null,
                    'status'               => 'pending',
                    'error_message'        => null,
                ]
            );
        }

        $count = count($result['giftCards']);
        WixHelper::log('Export Gift Cards', "Exported and saved $count gift card(s).", 'success');

        return response()->streamDownload(function () use ($result, $fromStoreId) {
            echo json_encode([
                'from_store_id' => $fromStoreId,
                'gift_cards'    => $result['giftCards'],
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'gift_cards.json', [
            'Content-Type' => 'application/json'
        ]);
    }

    // =========================================================
    // Import Gift Cards
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Gift Cards', "Import started for store: {$store->store_name}", 'info');

        $accessToken = WixHelper::getAccessToken($store->instance_id);
        if (!$accessToken) {
            WixHelper::log('Import Gift Cards', "Failed: Could not get access token for instanceId: {$store->instance_id}", 'error');
            return back()->with('error', 'Could not get Wix access token.');
        }

        if (!$request->hasFile('giftcards_json')) {
            WixHelper::log('Import Gift Cards', "No file uploaded for store: {$store->store_name}", 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $file    = $request->file('giftcards_json');
        $json    = file_get_contents($file->getRealPath());
        $decoded = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE || !isset($decoded['from_store_id'], $decoded['gift_cards']) || !is_array($decoded['gift_cards'])) {
            WixHelper::log('Import Gift Cards', "Invalid JSON structure in uploaded file.", 'error');
            return back()->with('error', 'Invalid JSON structure. Required keys: from_store_id and gift_cards.');
        }

        $fromStoreId = $decoded['from_store_id'];
        $giftCards   = $decoded['gift_cards'];

        $imported = 0;
        $errors   = [];

        foreach ($giftCards as $gc) {
            $sourceId = $gc['id'] ?? null;
            if (!$sourceId) {
                continue;
            }

            $migration = WixGiftCardMigration::where([
                'user_id'             => $userId,
                'from_store_id'       => $fromStoreId,
                'source_gift_card_id' => $sourceId,
            ])->first();

            if ($migration && $migration->status === 'success') {
                continue;
            }

            // ---- Build clean payload (strip read-only / unknown fields)
            $payloadGc = $gc;
            unset(
                $payloadGc['id'],
                $payloadGc['balance'],
                $payloadGc['createdDate'],
                $payloadGc['updatedDate'],
                $payloadGc['disabledDate'],
                $payloadGc['orderInfo'],
                $payloadGc['code'] // remove obfuscated code
            );

            // Normalize amount: always string with 2 decimals
            $amountRaw = $payloadGc['initialValue']['amount'] ?? null;
            $amountStr = $amountRaw !== null ? number_format((float)$amountRaw, 2, '.', '') : null;

            // Decide currency: prefer payload; else read store currency; else USD
            $resolvedCurrency = $payloadGc['currency'] ?? $this->getStoreCurrency($accessToken) ?? 'USD';

            $giftCardForCreate = [
                'initialValue' => [
                    'amount' => $amountStr,
                ],
                'currency' => $resolvedCurrency,
                'source'   => $payloadGc['source'] ?? 'MANUAL',
            ];

            if (!empty($payloadGc['expirationDate'])) {
                $giftCardForCreate['expirationDate'] = $payloadGc['expirationDate'];
            }

            // Sanitize & attach notificationInfo only if valid (recipient+sender); unknown keys dropped
            if (!empty($payloadGc['notificationInfo']) && is_array($payloadGc['notificationInfo'])) {
                $cleanNI = $this->sanitizeNotificationInfo($payloadGc['notificationInfo']);
                if ($cleanNI) {
                    $giftCardForCreate['notificationInfo'] = $cleanNI;
                }
            }

            // Optional: allow custom full code if you added it during export
            if (!empty($payloadGc['code_full'])) {
                $giftCardForCreate['code'] = $payloadGc['code_full'];
            }

            // Validate required fields before hit
            if (empty($giftCardForCreate['initialValue']['amount']) || empty($giftCardForCreate['currency'])) {
                $err = 'Missing required initialValue.amount or currency.';
                $errors[] = $err;

                WixGiftCardMigration::updateOrCreate(
                    [
                        'user_id'             => $userId,
                        'from_store_id'       => $fromStoreId,
                        'source_gift_card_id' => $sourceId,
                    ],
                    [
                        'to_store_id'           => $toStoreId,
                        'initial_value_amount'  => $gc['initialValue']['amount'] ?? null,
                        'currency'              => $gc['currency'] ?? null,
                        'status'                => 'failed',
                        'error_message'         => $err,
                    ]
                );

                WixHelper::log('Import Gift Cards', "Skip '$sourceId': $err", 'error');
                continue;
            }

            // Create with retry-smart POST (alt schema if 500)
            $payload = [
                'giftCard'       => $giftCardForCreate,
                'idempotencyKey' => 'gc-'.$this->uuid4(),
            ];
            $result = $this->createGiftCardInWix($accessToken, $payload);

            if (isset($result['giftCard']['id'])) {
                $imported++;

                WixGiftCardMigration::updateOrCreate(
                    [
                        'user_id'             => $userId,
                        'from_store_id'       => $fromStoreId,
                        'source_gift_card_id' => $sourceId,
                    ],
                    [
                        'to_store_id'               => $toStoreId,
                        'destination_gift_card_id'  => $result['giftCard']['id'],
                        'initial_value_amount'      => $giftCardForCreate['initialValue']['amount'] ?? null,
                        'currency'                  => $giftCardForCreate['currency'] ?? null,
                        'status'                    => 'success',
                        'error_message'             => null,
                    ]
                );

                WixHelper::log('Import Gift Cards', "Imported gift card (new ID: {$result['giftCard']['id']})", 'success');
            } else {
                $errorMsg = json_encode([
                    'status'   => $result['status'] ?? null,
                    'sent'     => ['giftCard' => $giftCardForCreate],
                    'response' => $result
                ]);

                $errors[] = $errorMsg;

                WixGiftCardMigration::updateOrCreate(
                    [
                        'user_id'             => $userId,
                        'from_store_id'       => $fromStoreId,
                        'source_gift_card_id' => $sourceId,
                    ],
                    [
                        'to_store_id'           => $toStoreId,
                        'initial_value_amount'  => $giftCardForCreate['initialValue']['amount'] ?? null,
                        'currency'              => $giftCardForCreate['currency'] ?? null,
                        'status'                => 'failed',
                        'error_message'         => $errorMsg,
                    ]
                );

                WixHelper::log('Import Gift Cards', "Failed to import '$sourceId' " . $errorMsg, 'error');
            }
        }

        if ($imported > 0) {
            WixHelper::log(
                'Import Gift Cards',
                "Import finished: $imported gift card(s) imported."
                . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""),
                'success'
            );
            return back()->with(
                'success',
                "$imported gift card(s) imported."
                . (count($errors) ? " Some errors: " . implode("; ", $errors) : "")
            );
        } else {
            WixHelper::log('Import Gift Cards', "No gift cards imported. Errors: " . implode("; ", $errors), 'error');
            return back()->with('error', 'No gift cards imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));
        }
    }

    // =========================================================
    // Utilities
    // =========================================================
    public function getGiftCardsFromWix($accessToken)
    {
        $endpoint = 'https://www.wixapis.com/gift-cards/v1/gift-cards/query';
        $all      = [];
        $cursor   = null;

        do {
            $body = [
                'query' => [
                    'cursorPaging' => [
                        'limit' => 100
                    ]
                ]
            ];
            if ($cursor) {
                $body['query']['cursorPaging']['cursor'] = $cursor;
            }

            $response = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type'  => 'application/json'
            ])->post($endpoint, $body);

            WixHelper::log('Export Gift Cards', 'Wix API raw response: ' . $response->body(), 'debug');

            if (!$response->ok()) {
                return ['error' => ['status' => $response->status(), 'body' => $response->body()]];
            }

            $json = $response->json();

            if (!isset($json['giftCards'])) {
                return ['error' => ['status' => $response->status(), 'body' => $response->body()]];
            }

            $all = array_merge($all, $json['giftCards']);

            $cursor = $json['pagingMetadata']['cursors']['next'] ?? null;
        } while ($cursor);

        return ['giftCards' => $all];
    }

    public function createGiftCardInWix($accessToken, array $payload)
    {
        // Attempt #1: root currency (matches Wix example)
        $resp1 = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/gift-cards/v1/gift-cards', $payload);

        WixHelper::log(
            'Import Gift Cards',
            'Create GC attempt#1 status=' . $resp1->status() . ' body=' . $resp1->body(),
            $resp1->ok() ? 'debug' : 'error'
        );

        if ($resp1->ok()) {
            return $resp1->json();
        }

        // Attempt #2: move currency into initialValue if server error (schema quirk on some tenants)
        if ($resp1->status() === 500 && isset($payload['giftCard'])) {
            $alt = $payload;
            if (isset($alt['giftCard']['currency'])) {
                $altCurrency = $alt['giftCard']['currency'];
                unset($alt['giftCard']['currency']);
                $alt['giftCard']['initialValue']['currency'] = $altCurrency;
            }

            $resp2 = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type'  => 'application/json'
            ])->post('https://www.wixapis.com/gift-cards/v1/gift-cards', $alt);

            WixHelper::log(
                'Import Gift Cards',
                'Create GC attempt#2 (alt schema) status=' . $resp2->status() . ' body=' . $resp2->body(),
                $resp2->ok() ? 'debug' : 'error'
            );

            if ($resp2->ok()) {
                return $resp2->json();
            }

            return $resp2->json();
        }

        // Fallthrough: return first error body
        return $resp1->json();
    }

    /**
     * Keep only allowed fields in notificationInfo.
     * Requires BOTH recipient and sender to include notificationInfo.
     * Drops unknown fields like imageUrl.
     */
    protected function sanitizeNotificationInfo(array $ni): ?array
    {
        $recipient = null;
        if (!empty($ni['recipient']) && is_array($ni['recipient'])) {
            $rec = [];
            if (!empty($ni['recipient']['email'])) $rec['email'] = $ni['recipient']['email'];
            if (!empty($ni['recipient']['name']))  $rec['name']  = $ni['recipient']['name'];
            if (!empty($rec)) $recipient = $rec;
        }

        $sender = null;
        if (!empty($ni['sender']) && is_array($ni['sender'])) {
            $sen = [];
            if (!empty($ni['sender']['email'])) $sen['email'] = $ni['sender']['email'];
            if (!empty($ni['sender']['name']))  $sen['name']  = $ni['sender']['name'];
            if (!empty($sen)) $sender = $sen;
        }

        if (!$recipient || !$sender) {
            return null; // require both to send notification
        }

        $clean = [
            'recipient' => $recipient,
            'sender'    => $sender,
        ];

        if (!empty($ni['notificationDate'])) {
            $clean['notificationDate'] = $ni['notificationDate'];
        }
        if (!empty($ni['personalizedMessage'])) {
            $clean['personalizedMessage'] = $ni['personalizedMessage'];
        }

        return $clean;
    }

    /**
     * Try to read store currency; fallback handled by caller.
     */
    protected function getStoreCurrency(string $accessToken): ?string
    {
        $resp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->get('https://www.wixapis.com/stores/v2/settings');

        if (!$resp->ok()) {
            WixHelper::log('Import Gift Cards', 'Get store settings failed: status=' . $resp->status() . ' body=' . $resp->body(), 'error');
            return null;
        }

        $j = $resp->json();
        return $j['storeSettings']['currency'] ?? $j['currency'] ?? null;
    }

    /**
     * Simple UUID v4 generator for idempotencyKey.
     */
    protected function uuid4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
