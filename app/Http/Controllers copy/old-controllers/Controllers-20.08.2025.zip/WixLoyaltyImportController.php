<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use App\Models\WixStore;
use App\Models\WixLoyaltyImportMigration;
use App\Helpers\WixHelper;
use Illuminate\Support\Facades\Storage;

class WixLoyaltyImportController extends Controller
{
    // =========================================================
    // Export Loyalty Program Cards
    // =========================================================
    public function export(WixStore $store)
    {
        $userId = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Loyalty', 'Failed to get access token.', 'error');
            return response()->json(['error' => 'You are not authorized to access.'], 401);
        }

        $resp = $this->getLoyaltyImportsFromWix($accessToken);

        if (!isset($resp['loyaltyImports']) || !is_array($resp['loyaltyImports'])) {
            WixHelper::log('Export Loyalty', 'Failed to fetch loyalty imports: ' . json_encode($resp), 'error');
            return response()->json(['error' => 'Failed to fetch loyalty imports from Wix.'], 500);
        }

        $imports = $resp['loyaltyImports'];

        foreach ($imports as $imp) {
            WixLoyaltyImportMigration::updateOrCreate([
                'user_id'         => $userId,
                'from_store_id'   => $fromStoreId,
                'source_import_id'=> $imp['id'],
            ], [
                'status'    => strtolower($imp['status'] ?? 'unknown'),
                'file_name' => $imp['fileMetadata']['name'] ?? null,
                'file_url'  => $imp['fileMetadata']['url'] ?? null,
            ]);
        }

        return response()->streamDownload(function () use ($fromStoreId, $imports) {
            echo json_encode([
                'from_store_id'   => $fromStoreId,
                'loyaltyImports'  => $imports
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'loyalty_imports.json', ['Content-Type' => 'application/json']);
    }


    // =========================================================
    // Import Loyalty Program Cards
    // =========================================================
    // public function import(Request $request, WixStore $store)
    // {
    //     $userId = Auth::id();
    //     $toStoreId = $store->instance_id;

    //     if (!$request->hasFile('loyalty_json')) {
    //         return back()->with('error', 'No CSV file uploaded.');
    //     }

    //     $file = $request->file('loyalty_json');
    //     $filePath = $file->store('public/loyalty');
    //     $fileSize = $file->getSize();
    //     $fileName = $file->getClientOriginalName();
    //     $fileUrl = Storage::url($filePath);

    //     $accessToken = WixHelper::getAccessToken($toStoreId);
    //     if (!$accessToken) {
    //         return back()->with('error', 'Unauthorized');
    //     }

    //     $body = [
    //         'fileUrl' => $fileUrl,
    //         'fileName' => $fileName,
    //         'fileSize' => $fileSize
    //     ];

    //     $response = Http::withHeaders([
    //         'Authorization' => $accessToken,
    //         'Content-Type' => 'application/json',
    //     ])->post('https://www.wixapis.com/_api/loyalty-imports/v1/loyalty-imports', $body);

    //     if (!$response->ok()) {
    //         return back()->with('error', 'Failed to import loyalty file.');
    //     }

    //     $import = $response->json('loyaltyImport');

    //     WixLoyaltyImportMigration::create([
    //         'user_id' => $userId,
    //         'from_store_id' => null,
    //         'to_store_id' => $toStoreId,
    //         'source_import_id' => $import['id'],
    //         'status' => strtolower($import['status'] ?? 'unknown'),
    //         'file_name' => $fileName,
    //         'file_url' => $fileUrl,
    //     ]);

    //     return back()->with('success', 'Loyalty import submitted successfully.');
    // }

    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Loyalty Program Cards', "Import started for store: {$store->store_name}", 'info');

        if (!$request->hasFile('loyalty_json')) {
            WixHelper::log('Import Loyalty Program Cards', "No file uploaded.", 'error');
            return back()->with('error', 'No CSV file uploaded.');
        }

        $file     = $request->file('loyalty_json');
        $filePath = $file->store('public/loyalty');
        $fileSize = $file->getSize();
        $fileName = $file->getClientOriginalName();
        $fileUrl  = Storage::url($filePath);

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Loyalty Program Cards', "Failed to get access token.", 'error');
            return back()->with('error', 'Unauthorized');
        }

        $result = $this->importLoyaltyFileToWix($accessToken, $fileUrl, $fileName, $fileSize);

        if (isset($result['loyaltyImport']['id'])) {
            $import = $result['loyaltyImport'];
            WixLoyaltyImportMigration::create([
                'user_id'        => $userId,
                'from_store_id'  => null,
                'to_store_id'    => $toStoreId,
                'source_import_id'=> $import['id'],
                'status'         => strtolower($import['status'] ?? 'unknown'),
                'file_name'      => $fileName,
                'file_url'       => $fileUrl,
            ]);

            WixHelper::log('Import Loyalty Program Cards', "Import submitted (ID: {$import['id']})", 'success');
            return back()->with('success', 'Loyalty import submitted successfully.');
        } else {
            $errorMsg = json_encode($result);
            WixHelper::log('Import Loyalty Program Cards', "Failed to import: $errorMsg", 'error');
            return back()->with('error', 'Failed to import loyalty file.');
        }
    }

    // =========================================================
    // Utilities
    // =========================================================
    public function getLoyaltyImportsFromWix($accessToken)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post('https://www.wixapis.com/_api/loyalty-imports/v1/loyalty-imports/query', [
            'query' => new \stdClass()
        ]);

        WixHelper::log('Export Loyalty', 'Wix API raw response: ' . $response->body(), 'debug');

        return $response->json();
    }


    private function importLoyaltyFileToWix($accessToken, $fileUrl, $fileName, $fileSize)
    {
        $body = [
            'fileUrl'  => $fileUrl,
            'fileName' => $fileName,
            'fileSize' => $fileSize
        ];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ])->post('https://www.wixapis.com/_api/loyalty-imports/v1/loyalty-imports', $body);

        return $response->json();
    }

}
