<?php

namespace App\Http\Controllers;

use App\Models\WixStore;
use App\Helpers\WixHelper;
use App\Models\WixContactMigration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WixContactController extends Controller
{
    // =========================================================
    // Export Contacts (+ member data: followers, following, badges, activity)
    // =========================================================
    public function export(WixStore $store)
    {
        $userId = Auth::id() ?: 1;
        $fromStoreId = $store->instance_id;

        WixHelper::log('Export Contacts', "Export started for store: {$store->store_name}", 'info');

        $accessToken = WixHelper::getAccessToken($fromStoreId);
        if (!$accessToken) {
            WixHelper::log('Export Contacts', "Failed: Could not get access token for instanceId: $fromStoreId", 'error');
            return response()->json(['error' => 'You are not authorized to access.'], 401);
        }

        $contacts = $this->getContactsFromWix($accessToken);
        if (isset($contacts['error'])) {
            WixHelper::log('Export Contacts', "API error: " . $contacts['raw'], 'error');
            return response()->json(['error' => $contacts['error']], 500);
        }

        // --- Label Handling ---
        $allLabelKeys = [];
        foreach ($contacts as $contact) {
            if (!empty($contact['labelKeys'])) {
                $allLabelKeys = array_merge($allLabelKeys, $contact['labelKeys']);
            }
        }
        $allLabelKeys = array_unique($allLabelKeys);

        $labelMap = [];
        foreach ($allLabelKeys as $labelKey) {
            $labelResp = $this->getLabelFromWix($accessToken, $labelKey);
            if (isset($labelResp['displayName'])) {
                $labelMap[$labelKey] = $labelResp['displayName'];
            }
        }

        // --- Extended Field defs (only export user fields) ---
        $extendedFieldDefs = $this->getAllExtendedFields($accessToken);

        foreach ($contacts as &$contact) {
            // Labels => humanized
            $contact['labels'] = [];
            if (!empty($contact['labelKeys'])) {
                foreach ($contact['labelKeys'] as $key) {
                    $contact['labels'][] = [
                        'key' => $key,
                        'displayName' => $labelMap[$key] ?? $key
                    ];
                }
            }

            // Extended fields: only user-defined (not system)
            $contact['extendedFields'] = [];
            $items = $contact['info']['extendedFields']['items'] ?? [];
            foreach ($items as $key => $value) {
                $def = $extendedFieldDefs[$key] ?? null;
                if (!isset($def['dataType']) || !isset($def['displayName'])) continue;
                if ($this->isSystemExtendedField($def['displayName'])) continue;
                $contact['extendedFields'][] = [
                    'key' => $key,
                    'displayName' => $def['displayName'],
                    'dataType' => $def['dataType'],
                    'value' => $value,
                ];
            }

            // Attachments
            $contact['attachments'] = [];
            if (!empty($contact['id'])) {
                $atts = $this->listContactAttachments($accessToken, $contact['id']);
                foreach ($atts as $att) {
                    $attFile = $this->downloadContactAttachment($accessToken, $contact['id'], $att['id']);
                    $contact['attachments'][] = [
                        'fileName' => $att['fileName'],
                        'mimeType' => $att['mimeType'],
                        'meta' => $att,
                        'content_base64' => isset($attFile['content']) ? base64_encode($attFile['content']) : null
                    ];
                }
            }

            // MEMBER DATA (if this contact is a member)
            $contact['member'] = null;
            $contactId = $contact['id'] ?? null;
            if ($contactId) {
                $member = $this->findMemberByContactId($accessToken, $contactId);
                if ($member) {
                    $memberId = $member['id'];

                    $contact['member'] = [
                        'id'                 => $memberId,
                        'loginEmail'         => $member['loginEmail'] ?? null,
                        'profile'            => $member['profile'] ?? null,
                        'followers'          => $this->getMemberFollowers($accessToken, $memberId, 'followers'),
                        'following'          => $this->getMemberFollowers($accessToken, $memberId, 'following'),
                        'badges'             => $this->getMemberBadges($accessToken, $memberId),
                        'activity_counters'  => $this->getMemberActivityCounters($accessToken, $memberId),
                    ];

                    // Fetch Member About
                    $memberAbout = $this->getMemberAbout($accessToken, $memberId);
                    if ($memberAbout) {
                        $contact['member']['about'] = $memberAbout;
                    }
                }
            }
        }
        unset($contact);

        // --- Custom Fields ---
        $customFields = $this->getAllCustomFields($accessToken);

        // --- Custom Field Applications for all custom fields ---
        $customFieldIds = array_map(fn($f) => $f['id'], $customFields);
        $customFieldApplications = $this->getCustomFieldApplications($accessToken, $customFieldIds);

        // Save PENDING rows to wix_contact_migrations (media-like pattern)
        $pendingSaved = 0;
        foreach ($contacts as $c) {
            $email = $c['info']['emails']['items'][0]['email'] ?? null;
            $name  = $c['info']['name']['first']
                ?? ($c['info']['name']['formatted'] ?? null);

            if (!$email) {
                WixHelper::log('Export Contacts', 'Skipped pending row: contact has no email', 'warn');
                continue;
            }

            WixContactMigration::updateOrCreate(
                [
                    'user_id'       => $userId,
                    'from_store_id' => $fromStoreId,
                    'to_store_id'   => null, // export phase
                    'contact_email' => $email,
                ],
                [
                    'contact_name'            => $name,
                    'destination_contact_id'  => null,
                    'status'                  => 'pending',
                    'error_message'           => null,
                ]
            );
            $pendingSaved++;
        }

        $payload = [
            'from_store_id'           => $fromStoreId,
            'contacts'                => $contacts,
            'customFields'            => $customFields,
            'customFieldApplications' => $customFieldApplications,
        ];

        WixHelper::log('Export Contacts', "Exported " . count($contacts) . " contacts; saved {$pendingSaved} pending row(s).", 'success');

        return response()->streamDownload(function() use ($payload) {
            echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }, 'contacts.json', [
            'Content-Type' => 'application/json'
        ]);
    }

    // =========================================================
    // Import Contacts (+ member data restore; skip dup contacts)
    // 1) Create/merge contacts
    // 2) Create members for those contacts that had member data
    // 3) Second pass: restore followers/following and badges
    // =========================================================
    public function import(Request $request, WixStore $store)
    {
        $userId    = Auth::id() ?: 1;
        $toStoreId = $store->instance_id;

        WixHelper::log('Import Contacts', "Import started for store: $store->store_name", 'info');

        $accessToken = WixHelper::getAccessToken($toStoreId);
        if (!$accessToken) {
            WixHelper::log('Import Contacts', "Failed: Could not get access token.", 'error');
            return back()->with('error', 'Could not get Wix access token.');
        }

        if (!$request->hasFile('contacts_json')) {
            WixHelper::log('Import Contacts', "No file uploaded.", 'error');
            return back()->with('error', 'No file uploaded.');
        }

        $file    = $request->file('contacts_json');
        $json    = file_get_contents($file->getRealPath());
        $decoded = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE || !isset($decoded['from_store_id'], $decoded['contacts']) || !is_array($decoded['contacts'])) {
            WixHelper::log('Import Contacts', "Invalid JSON structure.", 'error');
            return back()->with('error', 'Invalid JSON structure. Required keys: from_store_id and contacts.');
        }

        $fromStoreId       = $decoded['from_store_id'];
        $contacts          = $decoded['contacts'];
        $customFields      = $decoded['customFields'] ?? [];
        $customFieldApps   = $decoded['customFieldApplications'] ?? [];

        // Sort contacts by createdDate ascending
        usort($contacts, function($a, $b) {
            $dateA = $a['createdDate'] ?? null;
            $dateB = $b['createdDate'] ?? null;

            if (!$dateA && !$dateB) return 0;
            if (!$dateA) return -1;
            if (!$dateB) return 1;

            return strtotime($dateA) <=> strtotime($dateB);
        });

        $importedContacts  = 0;
        $errors            = [];
        $oldMemberIdToNewMemberId = [];
        $oldContactIdToNewContactId = [];

        WixHelper::log('Import Contacts', 'Parsed '.count($contacts).' contact(s).', 'info');

        // ========== PASS 0: Create missing custom fields ==========
        $existingFields = [];
        $allCustomFields = $this->getAllCustomFields($accessToken);
        foreach ($allCustomFields as $field) {
            $existingFields[$field['key']] = $field;
        }

        foreach ($customFields as $field) {
            if (!isset($existingFields[$field['key']])) {
                $resp = Http::withHeaders([
                    'Authorization' => $accessToken,
                    'Content-Type'  => 'application/json'
                ])->post('https://www.wixapis.com/members/v1/custom-fields', [
                    'field' => [
                        'name' => $field['name'],
                        'fieldType' => $field['fieldType'],
                        'defaultPrivacy' => $field['defaultPrivacy'],
                        'socialType' => $field['socialType'] ?? 'UNKNOWN'
                    ]
                ]);
                // Optional: add a debug log if needed
                if (!$resp->ok()) {
                    WixHelper::log('Import Contacts', 'Custom field create failed: '.$resp->status().' | '.$resp->body(), 'warn');
                }
            }
        }

        // ========= PASS 1: Contacts (and immediate member create if needed) =========
        foreach ($contacts as $contact) {
            // Remove system fields
            unset(
                $contact['id'], $contact['revision'], $contact['source'],
                $contact['createdDate'], $contact['updatedDate'],
                $contact['memberInfo'], $contact['primaryEmail'],
                $contact['primaryInfo'], $contact['picture']
            );

            $info = $contact['info'] ?? $contact;

            // Allowed keys in info
            $allowedInfoKeys = [
                'name', 'emails', 'phones', 'addresses', 'company',
                'jobTitle', 'birthdate', 'locale', 'labelKeys',
                'extendedFields', 'locations'
            ];

            $filteredInfo = [];
            foreach ($allowedInfoKeys as $key) {
                if (isset($info[$key])) {
                    $filteredInfo[$key] = $info[$key];
                }
            }

            // Format nested arrays
            foreach (['emails', 'phones', 'addresses'] as $field) {
                if (!empty($filteredInfo[$field]['items'])) {
                    $filteredInfo[$field] = ['items' => array_values($filteredInfo[$field]['items'])];
                } else {
                    unset($filteredInfo[$field]);
                }
            }

            // Only allow custom.* keys in extendedFields (if any)
            if (!empty($filteredInfo['extendedFields']['items'])) {
                $filteredInfo['extendedFields']['items'] = array_filter(
                    $filteredInfo['extendedFields']['items'],
                    fn($k) => strpos($k, 'custom.') === 0,
                    ARRAY_FILTER_USE_KEY
                );
                if (empty($filteredInfo['extendedFields']['items'])) {
                    unset($filteredInfo['extendedFields']);
                }
            }

            $email = $filteredInfo['emails']['items'][0]['email'] ?? null;
            $name  = $filteredInfo['name']['first'] ?? ($filteredInfo['name']['formatted'] ?? null);

            // Dedupe by email
            if ($email) {
                $existingContact = $this->findContactByEmail($accessToken, $email);
                if ($existingContact) {
                    WixHelper::log('Import Contacts', "Skipped: Contact with email $email already exists in target store.", 'warning');
                    // record mapping for potential use
                    $oldId = $contact['info']['_old_id'] ?? null; // optional
                    if ($oldId && isset($existingContact['id'])) {
                        $oldContactIdToNewContactId[$oldId] = $existingContact['id'];
                    }
                    $newContactId = $existingContact['id'] ?? null;
                } else {
                    $newContactId = null;
                }
            }

            // ----- LABELS -----
            $labelKeys = [];
            if (!empty($contact['labels'])) {
                foreach ($contact['labels'] as $label) {
                    $displayName = $label['displayName'] ?? $label['key'] ?? null;
                    if ($displayName) {
                        $labelResp = $this->findOrCreateLabelInWix($accessToken, $displayName);
                        if (isset($labelResp['key'])) {
                            $labelKeys[] = $labelResp['key'];
                        }
                    }
                }
            }
            if (!empty($labelKeys)) {
                $filteredInfo['labelKeys'] = $labelKeys;
            }

            // ----- EXTENDED FIELDS -----
            $extendedFieldItems = [];
            if (!empty($contact['extendedFields'])) {
                foreach ($contact['extendedFields'] as $extField) {
                    $displayName = $extField['displayName'] ?? null;
                    $dataType    = $extField['dataType'] ?? 'TEXT';
                    $value       = $extField['value'] ?? null;
                    if ($this->isSystemExtendedField($displayName)) continue;
                    if ($displayName && $value !== null) {
                        $key = $this->findOrCreateExtendedField($accessToken, $displayName, $dataType);
                        if ($key) $extendedFieldItems[$key] = $value;
                    }
                }
            }
            if ($extendedFieldItems) {
                $filteredInfo['extendedFields'] = ['items' => $extendedFieldItems];
            }

            // Remove empties
            $filteredInfo = $this->cleanEmpty($filteredInfo);

            // Validate required fields
            if (!$name && !$email && empty($filteredInfo['phones']['items'])) {
                $msg = "Contact missing required fields (name/email/phone)";
                $errors[] = $msg;
                WixContactMigration::updateOrCreate([
                    'user_id'       => $userId,
                    'from_store_id' => $fromStoreId,
                    'to_store_id'   => $toStoreId,   // target-aware key
                    'contact_email' => $email,
                ], [
                    'contact_name'            => $name,
                    'destination_contact_id'  => null,
                    'status'                  => 'failed',
                    'error_message'           => $msg,
                ]);
                continue;
            }

            // Create contact if not deduped earlier
            if (!isset($newContactId)) {
                $result = $this->createContactInWix($accessToken, $filteredInfo);
                if (isset($result['contact']['id'])) {
                    $importedContacts++;
                    $newContactId = $result['contact']['id'];
                    WixHelper::log('Import Contacts', "Imported contact: " . ($name ?? 'Unknown'), 'success');
                } else {
                    // Log detailed failure
                    $errMsg = json_encode(['sent' => $filteredInfo, 'response' => $result]);
                    $errors[] = $errMsg;
                    WixContactMigration::updateOrCreate([
                        'user_id'       => $userId,
                        'from_store_id' => $fromStoreId,
                        'to_store_id'   => $toStoreId,   // target-aware key
                        'contact_email' => $email,
                    ], [
                        'contact_name'            => $name,
                        'destination_contact_id'  => null,
                        'status'                  => 'failed',
                        'error_message'           => $errMsg,
                    ]);
                    WixHelper::log('Import Contacts', "Failed to import: $errMsg", 'error');
                    // Skip member create if contact failed
                    unset($newContactId);
                    continue;
                }
            }

            // Save migration row (success)
            WixContactMigration::updateOrCreate([
                'user_id'       => $userId,
                'from_store_id' => $fromStoreId,
                'to_store_id'   => $toStoreId,       // target-aware key
                'contact_email' => $email,
            ], [
                'contact_name'            => $name,
                'destination_contact_id'  => $newContactId,
                'status'                  => 'success',
                'error_message'           => null,
            ]);

            // --- Import Attachments ---
            if (!empty($contact['attachments'])) {
                foreach ($contact['attachments'] as $att) {
                    if (!empty($att['fileName']) && !empty($att['mimeType']) && !empty($att['content_base64'])) {
                        $uploadUrlResp = $this->generateAttachmentUploadUrl($accessToken, $newContactId, $att['fileName'], $att['mimeType']);
                        if (!empty($uploadUrlResp['uploadUrl'])) {
                            $this->uploadFileToUrl($uploadUrlResp['uploadUrl'], base64_decode($att['content_base64']), $att['mimeType']);
                        }
                    }
                }
            }

            // ===== MEMBER CREATE (if member info present) =====
            if (!empty($contact['member'])) {
                $oldMemberId = $contact['member']['id'] ?? null;

                // Try to find existing member by email; if not create new
                $memberEmail   = $contact['member']['loginEmail'] ?? ($email ?? null);
                $memberProfile = $contact['member']['profile'] ?? [];
                $nickname      = $memberProfile['nickname'] ?? ($name ?? null);

                $existingMember = $memberEmail ? $this->findMemberByEmail($accessToken, $memberEmail) : null;
                if ($existingMember) {
                    $newMemberId = $existingMember['id'];
                } else {
                    $createBody = [
                        'loginEmail' => $memberEmail,
                        'profile'    => [
                            'nickname' => $nickname,
                        ],
                    ];
                    $created = $this->createMemberInWix($accessToken, $createBody);
                    $newMemberId = $created['member']['id'] ?? null;
                }

                if (!empty($newMemberId) && !empty($oldMemberId)) {
                    $oldMemberIdToNewMemberId[$oldMemberId] = $newMemberId;
                }

                // Import Member About
                if (!empty($contact['member']['about']) && !empty($newMemberId)) {
                    $about = $contact['member']['about'];
                    $aboutPayload = [
                        'memberAbout' => [
                            'memberId' => $newMemberId,
                            'content'  => $about['content'],
                            'revision' => $about['revision'] ?? '0'
                        ]
                    ];

                    $existingAbout = $this->getMemberAbout($accessToken, $newMemberId);
                    if ($existingAbout) {
                        Http::withHeaders([
                            'Authorization' => $accessToken,
                            'Content-Type'  => 'application/json'
                        ])->patch("https://www.wixapis.com/members/v2/abouts/{$existingAbout['id']}", $aboutPayload);
                    } else {
                        Http::withHeaders([
                            'Authorization' => $accessToken,
                            'Content-Type'  => 'application/json'
                        ])->post("https://www.wixapis.com/members/v2/abouts", $aboutPayload);
                    }
                }
            }

            unset($newContactId);
        }

        // ========= PASS 2: Restore member relationships (followers, following, badges) =========
        foreach ($contacts as $contact) {
            if (empty($contact['member'])) continue;

            $oldMemberId = $contact['member']['id'] ?? null;
            if (empty($oldMemberId) || empty($oldMemberIdToNewMemberId[$oldMemberId])) continue;

            $newMemberId = $oldMemberIdToNewMemberId[$oldMemberId];

            // Badges
            if (!empty($contact['member']['badges'])) {
                foreach ($contact['member']['badges'] as $badge) {
                    if (!empty($badge['badgeKey'])) {
                        $this->assignBadge($accessToken, $newMemberId, $badge['badgeKey']);
                    }
                }
            }

            // Following (make the imported member follow targets that were imported)
            if (!empty($contact['member']['following'])) {
                foreach ($contact['member']['following'] as $f) {
                    $followedOldId = $f['id'] ?? null;
                    if ($followedOldId && !empty($oldMemberIdToNewMemberId[$followedOldId])) {
                        $this->followMember($accessToken, $newMemberId, $oldMemberIdToNewMemberId[$followedOldId]);
                    }
                }
            }
        }

        if ($importedContacts > 0) {
            WixHelper::log(
                'Import Contacts',
                "Import finished: $importedContacts contact(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""),
                count($errors) ? 'warning' : 'success'
            );
            return back()->with('success', "$importedContacts contact(s) imported." . (count($errors) ? " Some errors: " . implode("; ", $errors) : ""));
        } else {
            WixHelper::log('Import Contacts', "No contacts imported. Errors: " . implode("; ", $errors), 'error');
            return back()->with('error', 'No contacts imported.' . (count($errors) ? " Errors: " . implode("; ", $errors) : ''));
        }
    }

    // =========================================================
    // Utilities (Contacts + Members)
    // =========================================================

    // -------- Contacts --------
    public function getContactsFromWix($accessToken, $limit = 1000)
    {
        $contacts = [];
        $offset = 0;
        $total = 0;

        do {
            $query = [
                'paging.limit'  => $limit,
                'paging.offset' => $offset,
                'fieldsets'     => 'FULL'
            ];

            $response = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type'  => 'application/json'
            ])->get('https://www.wixapis.com/contacts/v4/contacts', $query);

            WixHelper::log('Export Contacts', 'Query status: '.$response->status().', offset: '.$offset, 'info');

            if (!$response->ok()) {
                WixHelper::log('Export Contacts', "API error: " . $response->body(), 'error');
                return [
                    'error' => 'Failed to fetch contacts from Wix.',
                    'raw' => $response->body()
                ];
            }

            $data = $response->json();

            if (!isset($data['contacts'])) {
                WixHelper::log('Export Contacts', "API error: " . json_encode($data), 'error');
                return [
                    'error' => 'Failed to fetch contacts from Wix.',
                    'raw' => json_encode($data)
                ];
            }

            foreach ($data['contacts'] as $contact) {
                $contacts[] = $contact;
            }

            $count = $data['pagingMetadata']['count'] ?? 0;
            $total = $data['pagingMetadata']['total'] ?? 0;
            $offset += $count;

        } while ($count > 0 && $offset < $total);

        return $contacts;
    }

    private function cleanEmpty($array)
    {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                $array[$k] = $this->cleanEmpty($v);
                if ($array[$k] === [] || $array[$k] === null) unset($array[$k]);
            } elseif ($v === [] || $v === null) {
                unset($array[$k]);
            }
        }
        return $array;
    }

    // Labels
    private function getLabelFromWix($accessToken, $labelKey)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json'
        ])->get('https://www.wixapis.com/contacts/v4/labels/' . urlencode($labelKey));
        if ($response->ok()) {
            return $response->json();
        }
        return [];
    }
    private function findOrCreateLabelInWix($accessToken, $displayName)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json'
        ])->post('https://www.wixapis.com/contacts/v4/labels', [
            'displayName' => $displayName
        ]);
        if ($response->ok()) {
            return $response->json();
        }
        return [];
    }

    // Extended fields (Contacts v4)
    private function getAllExtendedFields($accessToken)
    {
        $fields = [];
        $offset = 0;
        $limit = 100;
        do {
            $query = [
                'paging.limit' => $limit,
                'paging.offset' => $offset,
            ];
            $resp = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type' => 'application/json'
            ])->get('https://www.wixapis.com/contacts/v4/extended-fields', $query);

            if (!$resp->ok()) break;

            $data = $resp->json();
            foreach ($data['extendedFields'] ?? [] as $f) {
                $fields[$f['key']] = [
                    'displayName' => $f['displayName'],
                    'dataType' => $f['dataType'],
                ];
            }

            $count = $data['pagingMetadata']['count'] ?? 0;
            $offset += $count;
        } while ($count > 0);
        return $fields;
    }

    public function updateCustomExtendedFields(WixStore $store, $contactId, array $customFields)
    {
        $accessToken = WixHelper::getAccessToken($store->instance_id);
        if (!$accessToken) {
            throw new \Exception('Could not get Wix access token');
        }

        $fieldKeys = [];
        foreach ($customFields as $displayName => $value) {
            if (strpos($displayName, 'custom.') !== 0) continue;
            $dataType = is_numeric($value) ? 'NUMBER' : 'TEXT';
            $key = $this->findOrCreateExtendedField($accessToken, $displayName, $dataType);
            if ($key) {
                $fieldKeys[$key] = $value;
            }
        }

        if (empty($fieldKeys)) {
            throw new \Exception('No valid custom fields provided');
        }

        $updateBody = [
            "extendedFields" => [
                "items" => $fieldKeys
            ]
        ];

        $url = "https://www.wixapis.com/contacts/v4/contacts/{$contactId}";
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->patch($url, ["info" => $updateBody]);

        if (!$response->ok()) {
            throw new \Exception("Failed to update custom fields: " . $response->body());
        }

        return $response->json();
    }

    private function findOrCreateExtendedField($accessToken, $displayName, $dataType)
    {
        $resp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json'
        ])->post('https://www.wixapis.com/contacts/v4/extended-fields', [
            'displayName' => $displayName,
            'dataType' => $dataType ?: 'TEXT'
        ]);
        if ($resp->ok() && !empty($resp->json()['key'])) {
            return $resp->json()['key'];
        }
        return null;
    }

    private function isSystemExtendedField($displayName)
    {
        if (!$displayName) return true;
        return preg_match('/^(emailSubscriptions\.|contacts\.)/', $displayName);
    }

    private function findContactByEmail($accessToken, $email)
    {
        $query = [
            "query" => [
                "filter" => [
                    "info.emails.items.email" => [
                        "\$eq" => $email
                    ]
                ],
                "paging" => ["limit" => 1]
            ]
        ];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json'
        ])->post('https://www.wixapis.com/contacts/v4/contacts/query', $query);

        if ($response->ok() && !empty($response->json('contacts'))) {
            return $response->json('contacts')[0];
        }
        return null;
    }

    private function createContactInWix($accessToken, $info)
    {
        $body = [
            'info'            => (object)$info,
            'allowDuplicates' => true
        ];

        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/contacts/v4/contacts', $body);

        WixHelper::log('Import Contacts', "createContactInWix → {$response->status()} | " . $response->body(), $response->ok() ? 'debug' : 'warn');

        return $response->json();
    }

    // -------- Contact Attachments --------
    private function listContactAttachments($accessToken, $contactId)
    {
        $attachments = [];
        $limit = 100; $offset = 0;
        do {
            $query = [
                'paging.limit' => $limit,
                'paging.offset' => $offset,
            ];
            $response = Http::withHeaders([
                'Authorization' => $accessToken,
            ])->get("https://www.wixapis.com/contacts/v4/attachments/$contactId", $query);
            if (!$response->ok()) break;
            $data = $response->json();
            foreach ($data['attachments'] ?? [] as $att) $attachments[] = $att;
            $count = $data['pagingMetadata']['count'] ?? 0;
            $offset += $count;
        } while ($count > 0);
        return $attachments;
    }

    private function downloadContactAttachment($accessToken, $contactId, $attachmentId)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
        ])->get("https://www.wixapis.com/contacts/v4/attachments/$contactId/$attachmentId");
        if ($response->ok()) {
            return [
                'filename' => $response->header('content-disposition'),
                'mimeType' => $response->header('content-type'),
                'content' => $response->body(),
            ];
        }
        return null;
    }

    private function generateAttachmentUploadUrl($accessToken, $contactId, $fileName, $mimeType)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post("https://www.wixapis.com/contacts/v4/attachments/$contactId/upload-url", [
            'fileName' => $fileName,
            'mimeType' => $mimeType,
        ]);
        return $response->ok() ? $response->json() : null;
    }

    private function uploadFileToUrl($url, $fileContent, $mimeType)
    {
        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->put($url, [
                'body' => $fileContent,
                'headers' => [
                    'Content-Type' => $mimeType,
                ]
            ]);
            return $response->getStatusCode() === 200 || $response->getStatusCode() === 201;
        } catch (\Exception $e) {
            Log::error("Attachment upload failed: " . $e->getMessage());
            return false;
        }
    }

    // -------- Members helpers (tied to contacts) --------

    // Find member by contactId (preferred linkage)
    private function findMemberByContactId($accessToken, $contactId)
    {
        $query = [
            'query' => [
                'filter' => [
                    'contactId' => ['$eq' => $contactId]
                ],
                'paging' => ['limit' => 1]
            ]
        ];
        $resp = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/members/v1/members/query', $query);

        if ($resp->ok() && !empty($resp->json('members'))) {
            return $resp->json('members')[0];
        }
        return null;
    }

    private function findMemberByEmail($accessToken, $email)
    {
        if (!$email) return null;
        $query = [
            'query' => [
                'filter' => [
                    'loginEmail' => ['$eq' => $email]
                ],
                'paging' => ['limit' => 1]
            ]
        ];
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/members/v1/members/query', $query);
        if ($response->ok() && !empty($response->json('members'))) {
            return $response->json('members')[0];
        }
        return null;
    }

    private function createMemberInWix($accessToken, $body)
    {
        // API expects { member: { ... } }
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post('https://www.wixapis.com/members/v1/members', ['member' => $body]);
        return $response->json();
    }

    private function getMemberFollowers($accessToken, $memberId, $type = 'followers')
    {
        $endpoint = $type === 'followers'
            ? "https://www.wixapis.com/members/v1/members/$memberId/followers"
            : "https://www.wixapis.com/members/v1/members/$memberId/following";
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get($endpoint);
        return $response->ok() ? ($response->json()['members'] ?? []) : [];
    }

    private function followMember($accessToken, $memberId, $targetMemberId)
    {
        Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post("https://www.wixapis.com/members/v1/members/$memberId/following", [
            'memberId' => $targetMemberId
        ]);
    }

    private function getMemberBadges($accessToken, $memberId)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get("https://www.wixapis.com/members/v1/members/$memberId/badges");
        return $response->ok() ? ($response->json()['badges'] ?? []) : [];
    }

    private function assignBadge($accessToken, $memberId, $badgeKey)
    {
        Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->post("https://www.wixapis.com/members/v1/members/$memberId/badges", [
            'badgeKey' => $badgeKey
        ]);
    }

    private function getMemberActivityCounters($accessToken, $memberId)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json'
        ])->get("https://www.wixapis.com/members/v1/members/$memberId/activity-counters");
        return $response->ok() ? $response->json() : [];
    }

    // Get Member About by memberId
    private function getMemberAbout($accessToken, $memberId)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->get("https://www.wixapis.com/members/v2/abouts/member/$memberId");

        if ($response->ok()) {
            return $response->json('memberAbout') ?? null;
        }
        return null;
    }

    // Get all custom fields (Members v1)
    private function getAllCustomFields($accessToken)
    {
        $fields = [];
        $limit = 100;
        $offset = 0;
        do {
            $response = Http::withHeaders([
                'Authorization' => $accessToken,
                'Content-Type' => 'application/json',
            ])->get('https://www.wixapis.com/members/v1/custom-fields', [
                'paging.limit' => $limit,
                'paging.offset' => $offset,
            ]);

            if (!$response->ok()) {
                break;
            }

            $data = $response->json();
            foreach ($data['fields'] ?? [] as $field) {
                $fields[$field['key']] = $field;
            }

            $count = $data['metadata']['count'] ?? 0;
            $offset += $count;
        } while ($count > 0);

        return $fields;
    }

    // Get custom field applications for given custom field IDs (Members v1)
    private function getCustomFieldApplications($accessToken, array $customFieldIds)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->post('https://www.wixapis.com/members/v1/custom-fields-applications/applications', [
            'customFieldIds' => $customFieldIds
        ]);

        if ($response->ok()) {
            return $response->json('applications') ?? [];
        }
        return [];
    }

    // Get member's applied custom fields (boolean: true/false) (Members v1)
    private function getMembersCustomFieldApplications($accessToken, array $memberIds)
    {
        $response = Http::withHeaders([
            'Authorization' => $accessToken,
            'Content-Type' => 'application/json',
        ])->post('https://www.wixapis.com/members/v1/custom-fields-applications/members', [
            'memberIds' => $memberIds,
        ]);

        if ($response->ok()) {
            return $response->json('results') ?? [];
        }
        return [];
    }
}
